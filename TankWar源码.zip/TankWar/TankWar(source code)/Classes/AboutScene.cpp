#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include "SimpleAudioEngine.h"
#include"AboutScene.h"
#include"SoundManager.h"
#include"GameMenu.h"
#include "GameScene.h"

USING_NS_CC;
using namespace cocostudio::timeline;
using namespace cocos2d::ui;
using namespace CocosDenshion;

Scene* AboutScene::createScene()
{
	auto _scene = Scene::create();
	auto _layer = AboutScene::create();
	_scene->addChild(_layer);
	return _scene;
}
bool AboutScene::init()
{
	if (!Layer::init())
	{
		//log("aboutFalse");
		return false;
	}

	auto _aboutLayer = CSLoader::createNode("AboutScene.csb");
	this->addChild(_aboutLayer);
	m_aboutPanel = (Layout*)_aboutLayer->getChildByName("Panel");

	//��ȡ��ť
	m_backButton = (Button*)Helper::seekWidgetByName(m_aboutPanel, "BackButton");

	//���¼�
	m_backButton->addTouchEventListener(CC_CALLBACK_2(AboutScene::backMenu,this));
	return true;
}

void AboutScene::backMenu(cocos2d::Object* pSender, Widget::TouchEventType type)
{
	switch (type)
	{
	case Widget::TouchEventType::BEGAN:
		break;
	case Widget::TouchEventType::MOVED:
		break;
	case Widget::TouchEventType::ENDED:
		Director::getInstance()->replaceScene(TransitionFade::create(0.1f, GameMenu::createScene()));
		break;
	case Widget::TouchEventType::CANCELED:
		break;
	default:
		break;

	}
}