#pragma once
#include "cocos2d.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"

USING_NS_CC;
using namespace cocostudio::timeline;
using namespace cocos2d::ui;
class AboutScene :public Layer
{
private:
	Layout* m_aboutPanel;
	Button* m_backButton;


public:
	static Scene* createScene();
	bool init();
	CREATE_FUNC(AboutScene);
	void backMenu(cocos2d::Object* pSender, Widget::TouchEventType type);
	

};