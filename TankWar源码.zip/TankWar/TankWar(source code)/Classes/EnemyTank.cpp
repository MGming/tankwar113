#include "cocos2d.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include"EnemyTank.h"
#include"GameScene.h"
#include"EnemyManager.h"
#include"SoundManager.h"


USING_NS_CC;
using namespace cocostudio::timeline;
using namespace cocos2d::ui;


EnemyTank* EnemyTank::createEnemyWithType(int type)
{
	auto _enemy = new EnemyTank();
	if (_enemy&&_enemy->init(type))
	{
		_enemy->autorelease();
		return _enemy;
	}
	else
	{
		CC_SAFE_DELETE(_enemy);
		return nullptr;
	}
}
bool EnemyTank::init(int type)
{
	if (!Sprite::init())
	{
		return false;
	}
	m_tankType = type;
	srand(time(NULL));
	//̹�˳����ƶ�һ���ŻῪʼ���
	this->tankBear();
	auto _func = CallFunc::create([this] {this->tankMoveWithRandom(); this->startShoot(); });
	auto _dt = DelayTime::create(1);
	auto _act = Sequence::create(_dt, _func, nullptr);
	this->runAction(_act);

	return true;
}
void EnemyTank::tankInitWithType()
{
	
	switch(m_tankType)
	{
	  case NORMAL:
	  {
		  m_PH = 1;
		  m_moveVelocity = 5;
		  m_bulletVelocity = 200;
		  m_score = 100;
		  m_diretion[0] = new String("normalD.png");
		  m_diretion[1] = new String("normalU.png");
		  m_diretion[2] = new String("normalD.png");
		  m_diretion[3] = new String("normalL.png");
		  m_diretion[4] = new String("normalR.png");
		  this->setName("normalTank");
		  break;
	  }
	  case ARMOR:
	  {
		  m_PH = 3;
		  m_moveVelocity = 5;
		  m_bulletVelocity = 200;
		  m_score = 400;
		  m_diretion[0] = new String("armor3D.png");
		  m_diretion[1] = new String("armor3U.png");
		  m_diretion[2] = new String("armor3D.png");
		  m_diretion[3] = new String("armor3L.png");
		  m_diretion[4] = new String("armor3R.png");
		  this->setName("armor3Tank");
		  break;
	  }
	  case SPEED:
	  {
		  m_PH = 1;
		  m_moveVelocity = 10;
		  m_bulletVelocity = 200;
		  m_score = 200;
		  m_diretion[0] = new String("speedD.png");
		  m_diretion[1] = new String("speedU.png");
		  m_diretion[2] = new String("speedD.png");
		  m_diretion[3] = new String("speedL.png");
		  m_diretion[4] = new String("speedR.png");
		  this->setName("speedTank");
		  break;
	  }
	  case NORMAL_R:
	  {
		  m_PH = 1;
		  m_moveVelocity = 5;
		  m_bulletVelocity = 200;
		  m_score = 100;
		  m_diretion[0] = new String("normalD_R.png");
		  m_diretion[1] = new String("normalU_R.png");
		  m_diretion[2] = new String("normalD_R.png");
		  m_diretion[3] = new String("normalL_R.png");
		  m_diretion[4] = new String("normalR_R.png");
		  this->setName("normalTank_R");
		  break;
	  }
	  case ARMOR_R:
	  {
		  m_PH = 3;
		  m_moveVelocity = 5;
		  m_bulletVelocity = 200;
		  m_score = 400;
		  m_diretion[0] = new String("armor3D_R.png");
		  m_diretion[1] = new String("armor3U_R.png");
		  m_diretion[2] = new String("armor3D_R.png");
		  m_diretion[3] = new String("armor3L_R.png");
		  m_diretion[4] = new String("armor3R_R.png");
		  this->setName("armor3Tank_R");
		  break;
	  }
	  case SPEED_R:
	  {
		  m_PH = 1;
		  m_moveVelocity = 8;
		  m_bulletVelocity = 200;
		  m_score = 200;
		  m_diretion[0] = new String("speedD_R.png");
		  m_diretion[1] = new String("speedU_R.png");
		  m_diretion[2] = new String("speedD_R.png");
		  m_diretion[3] = new String("speedL_R.png");
		  m_diretion[4] = new String("speedR_R.png");
		  this->setName("speedTank_R");
		  break;
	  }
	  case SHOOT:
	  {
		  m_PH = 1;
		  m_moveVelocity = 5;
		  m_bulletVelocity = 400;
		  m_score = 300;
		  m_diretion[0] = new String("normalD.png");
		  m_diretion[1] = new String("normalU.png");
		  m_diretion[2] = new String("normalD.png");
		  m_diretion[3] = new String("normalL.png");
		  m_diretion[4] = new String("normalR.png");
		  this->setName("shootTank");
		  break;
	  }
	  case SHOOT_R:
	  {
		  m_PH = 1;
		  m_moveVelocity = 5;
		  m_bulletVelocity = 400;
		  m_score = 300;
		  m_diretion[0] = new String("normalD.png");
		  m_diretion[1] = new String("normalU.png");
		  m_diretion[2] = new String("normalD.png");
		  m_diretion[3] = new String("normalL.png");
		  m_diretion[4] = new String("normalR.png");
		  this->setName("shootTank");
		  break;
	  }

    }
	
	
	this->initWithSpriteFrameName(m_diretion[2]->getCString());
	this->m_moveDirection = 2;

}
void EnemyTank::onEnter()
{   
	Sprite::onEnter();
}
void EnemyTank::tankBear()
{
	float _ratio = 0.52;
	this->tankInitWithType();
	auto _tankHeroSize = this->getContentSize();
	this->setScale(_ratio);
	//this->setContentSize(_tankHeroSize*_ratio);
	this->m_shootSwitch = true;
	this->m_isTesting = false;
	this->setTag(GameScene::NodeTag::ENEMY_TAG);	
	this->m_moveStep = GameScene::getMapManager()->getMapLayer()->getMap()->getTileSize().height;
	this->m_isMoveing = false;

	auto animation = Animation::create();
	animation->addSpriteFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName("born1.png"));
	animation->addSpriteFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName("born2.png"));
	animation->addSpriteFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName("born3.png"));
	animation->addSpriteFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName("born4.png"));
	animation->setDelayPerUnit(0.1);//��������֡����ʱ����
	animation->setLoops(2);//�����Ƿ�ѭ������,-1����ѭ��,����n����n��,0������
	animation->setRestoreOriginalFrame(true);//���ö�����������Ƿ�ص���һ֡
	auto _bear = Animate::create(animation);
	auto _bearSprite = Sprite::create();
	_bearSprite->setPosition(Vec2(30, 30));
	this->addChild(_bearSprite);
	_bearSprite->runAction(_bear);
	_bearSprite->setScale(1.5);

	//��̹����һ��body�ӵ�����������,���������óߴ���Զ�����,,�������ﲻ�ó�������ϵ��
	auto body = PhysicsBody::createBox(this->getContentSize(), PhysicsMaterial(10, 0, 0));
	body->setVelocity(Vec2(0, 0));
	body->setCategoryBitmask(GameScene::CategoryMaskBit::ENEMY_CATEGORYMASKBIT);
	body->setContactTestBitmask(GameScene::ContactMaskBit::ENEMY_CONTACTMASKBIT);
	body->setCollisionBitmask(0); //��������ײģ��
	this->setPhysicsBody(body);

}
void EnemyTank::tankMove(float dt)
{
	//m_moveVelocity = 5;
	float _time = m_moveStep / (m_moveVelocity*m_moveStep);
	//���̹�˾��ε�����
	Rect _tankRect = this->getBoundingBox();
	float _x1 = _tankRect.getMinX();
	float _x2 = _tankRect.getMaxX();
	float _y1 = _tankRect.getMinY();
	float _y2 = _tankRect.getMaxY();
	float _stepX = 0;
	float _stepY = 0;
	Rect _moveRect;           //Ҫǰ����λ�õľ���

	if (m_moveDirection == 1)
	{
		this->setDisplayFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName(m_diretion[m_moveDirection]->getCString()));
		_stepY = m_moveStep;
		_moveRect.setRect(_x1 + _stepX, _y1 + _stepY, _x2 - _x1, _y2 - _y1);

		//���Ҫǰ����λ�õľ����Ƿ�����ϰ�
		if (!moveCollisionTest(_moveRect) && m_isMoveing != true)
		{
			
			this->m_isMoveing = true;
			auto _move = MoveBy::create(_time, Vec2(0, m_moveStep));
			auto _func = CallFunc::create([this]() {this->m_isMoveing = false; });
			auto _moveing = Sequence::create(_move, _func, nullptr);
			this->runAction(_moveing);
		}
		else if (moveCollisionTest(_moveRect) && m_isMoveing != true)
		{
			m_moveDirection = 4;
		}
	}
	else if (m_moveDirection == 2)
	{
		this->setDisplayFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName(m_diretion[m_moveDirection]->getCString()));
		_stepY = -m_moveStep;
		_moveRect.setRect(_x1 + _stepX, _y1 + _stepY, _x2 - _x1, _y2 - _y1);
		if (!moveCollisionTest(_moveRect) && m_isMoveing != true)
		{
			this->m_isMoveing = true;
			auto _move = MoveBy::create(_time, Vec2(0, -m_moveStep));
			auto _func = CallFunc::create([this]() {this->m_isMoveing = false; });
			auto _moveing = Sequence::create(_move, _func, nullptr);
			this->runAction(_moveing);
		}
		else if (moveCollisionTest(_moveRect) && m_isMoveing != true)
		{
			m_moveDirection = 3;
			
		}
	}
	else if (m_moveDirection == 3)
	{
		this->setDisplayFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName(m_diretion[m_moveDirection]->getCString()));
		_stepX = -m_moveStep;
		_moveRect.setRect(_x1 + _stepX, _y1 + _stepY, _x2 - _x1, _y2 - _y1);
		if (!moveCollisionTest(_moveRect) && m_isMoveing != true)
		{

			this->m_isMoveing = true;
			auto _move = MoveBy::create(_time, Vec2(-m_moveStep, 0));
			auto _func = CallFunc::create([this]() {this->m_isMoveing = false; });
			auto _moveing = Sequence::create(_move, _func, nullptr);
			this->runAction(_moveing);
			
		}
		else if (moveCollisionTest(_moveRect) && m_isMoveing != true)
		{
			m_moveDirection = 1;
			
		}
	}
	else if (m_moveDirection == 4)
	{
		this->setDisplayFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName(m_diretion[m_moveDirection]->getCString()));
		_stepX = m_moveStep;
		_moveRect.setRect(_x1 + _stepX, _y1 + _stepY, _x2 - _x1, _y2 - _y1);
		if (!moveCollisionTest(_moveRect) && m_isMoveing != true)
		{
			this->m_isMoveing = true;
			auto _move = MoveBy::create(_time, Vec2(m_moveStep, 0));
			auto _func = CallFunc::create([this]() {this->m_isMoveing = false; });
			auto _moveing = Sequence::create(_move, _func, nullptr);
			this->runAction(_moveing);
		}
		else if(moveCollisionTest(_moveRect)&&m_isMoveing != true)
		{
			m_moveDirection = 2;
		}
	}



}
bool EnemyTank::moveCollisionTest(Rect rect)
{
	auto _map = GameScene::getMapManager()->getMapLayer()->getMap();
	auto _mapLayer1 = _map->getLayer("layer1");
	int _gid = 0;
	auto _winSize = Director::getInstance()->getWinSize();
	auto _mapSize = _map->getContentSize();
	auto _tileSize = _map->getTileSize();

	//��ΪTMX��ͼ������ԭ�������Ͻ�,���º����ҷֱ�Ϊxy��������,��cocos��������ϵԭ�������½�,����������Ҫ��Y������ת��ΪTMX��ͼ������
	float _minY = _mapSize.height - rect.getMinY();
	float _maxY = _mapSize.height - rect.getMaxY();

	//�����layer1�ϸõ㲻�ǿհ�λ��,������ϰ�

	//�˶�����λ�ú��̹�����½ǵ�
	_gid = _mapLayer1->getTileGIDAt(Vec2((int)(rect.getMinX() / _tileSize.width), (int)(_minY / _tileSize.height)));
	//log("gid=%d", _gid);
	if (_gid != 0 && fabs(_gid)<1000)
		return true;

	//�˶�����λ�ú��̹�����Ͻǵ�
	_gid = _mapLayer1->getTileGIDAt(Vec2((int)(rect.getMinX() / _tileSize.width), (int)(_maxY / _tileSize.height)));
	//("gid=%d", _gid);
	if (_gid != 0 && fabs(_gid)<1000)
		return true;

	// �˶�����λ�ú��̹�����Ͻǵ�
	_gid = _mapLayer1->getTileGIDAt(Vec2((int)(rect.getMaxX() / _tileSize.width), (int)(_maxY / _tileSize.height)));
	//log("gid=%d", _gid);
	if (_gid != 0 && fabs(_gid)<1000)
		return true;

	// �˶�����λ�ú��̹�����½ǵ�
	_gid = _mapLayer1->getTileGIDAt(Vec2((int)(rect.getMaxX() / _tileSize.width), (int)(_minY / _tileSize.height)));
	//log("gid=%d", _gid);
	if (_gid != 0 && fabs(_gid)<1000)
		return true;

	// �˶�����λ�ú��̹�����нǵ�
	_gid = _mapLayer1->getTileGIDAt(Vec2((int)((rect.getMinX() + rect.getMaxX())*0.5 / _tileSize.width), (int)(_minY / _tileSize.height)));
	//log("gid=%d", _gid);
	if (_gid != 0 && fabs(_gid)<1000)
		return true;

	// �˶�����λ�ú��̹�����нǵ�
	_gid = _mapLayer1->getTileGIDAt(Vec2((int)((rect.getMinX() + rect.getMaxX())*0.5 / _tileSize.width), (int)(_maxY / _tileSize.height)));
	//log("gid=%d", _gid);
	if (_gid != 0 && fabs(_gid)<1000)
		return true;

	// �˶�����λ�ú��̹�����нǵ�
	_gid = _mapLayer1->getTileGIDAt(Vec2((int)(rect.getMinX() / _tileSize.width), (int)((_minY + _maxY)*0.5 / _tileSize.height)));
	//log("gid=%d", _gid);
	if (_gid != 0 && fabs(_gid)<1000)
		return true;

	// �˶�����λ�ú��̹�����нǵ�
	_gid = _mapLayer1->getTileGIDAt(Vec2((int)(rect.getMaxX() / _tileSize.width), (int)((_minY + _maxY)*0.5 / _tileSize.height)));
	//log("gid=%d", _gid);
	if (_gid != 0 && fabs(_gid)<1000)
		return true;

	//����õ����,Ҳ���谭
	if (rect.getMinY() < 0 || rect.getMinX() < 0 || rect.getMaxX() > _winSize.height || rect.getMaxY() > _winSize.height)
		return true;

	//̹���谭
	if (isTankBlock(rect))
		return true;
	
	return false;
}
void EnemyTank::tankMoveWithRandom()
{
	schedule(schedule_selector(EnemyTank::tankMove));
	schedule(schedule_selector(EnemyTank::tankMoveAI),4);
}

void EnemyTank::tankMoveStop()
{
	unschedule(schedule_selector(EnemyTank::tankMove));
	unschedule(schedule_selector(EnemyTank::tankMoveAI));
}
void EnemyTank::tankMoveAI(float dt)
{
	//�������
	int _vecD= random(1, 8);

    if(_vecD <= 4)
	{ 
		m_moveDirection = random(1, 4);
		this->shoot(dt);
	}
	else
		m_moveDirection = m_moveDirection;
}
bool EnemyTank::isTankBlock(Rect rect)
{
	auto _enemyTanks = GameScene::getEnemyManager()->getEnemyTankList()->getChildren();
	//�����з�̹��,�жϵз�̹�˼��Ƿ���ײ
	for (auto& _enemy : _enemyTanks)
	{	
		Rect _enemyRect = _enemy->getBoundingBox();

		//this->getTankNumber() != ((EnemyTank*)_enemy)->getTankNumber()�ų��Լ��Ľڵ�,������ʱ���غ;Ͳ�Ҫ����Ϊ�赲��
		if (_enemyRect.intersectsRect(this->getBoundingBox()) && this->getTankNumber() != ((EnemyTank*)_enemy)->getTankNumber())
		{
			return false;
		}

		//this->getTankNumber() != ((EnemyTank*)_enemy)->getTankNumber()�ų��Լ��Ľڵ�,Ҫ�ߵ�λ���غϾ�����Ϊ�赲
		if (_enemyRect.intersectsRect(rect) &&this->getTankNumber()!=((EnemyTank*)_enemy)->getTankNumber())     
		{
			return true;
		}
	}

	auto _hero = GameScene::getHeroManager()->getHeroTank();
	//�Ӹ��ж����,��ֹ�ҷ�̹��������Ϊ��ָ��
	if (_hero != nullptr)
	{ 
	     Rect _heroRect = _hero->getBoundingBox();

		 //ͬ��,������ʱ����ҷ�̹��ʱ��Ҫ����Ϊ�赲,��Ȼ˫�����߲���
	     if (this->getBoundingBox().intersectsRect(_heroRect))
	     {
			 return false;
		 }

	     if (rect.intersectsRect(_heroRect))
	     {		
		     return true;
	     }
	}
	return false;
}
void EnemyTank::shoot(float dt)
{
	int _sh = random(0, 1);             //��һ�������,���ӵ���������
	if (!this->getShootSwitch()||_sh!=1)        //����������Ϊfalse���ܷ����ӵ�
		return;

	this->setShootSwitch(false);
	//�����ӵ������뵽�ӵ���Ⱦ����
	auto bullet = EnemyBullet::createBullet(m_moveDirection,m_bulletVelocity);
	bullet->setPosition(this->getPosition());
	bullet->setBulletNumber(this->getTankNumber());
	GameScene::getBulletManager()->getBulletList()->addChild(bullet);
	//SoundManager::playShootSound();
	
}
void EnemyTank::onExit()
{
	Sprite::onExit();
}
void EnemyTank::getHurt(int hurt)
{
	int _hurt = hurt;
	m_PH -= hurt;

	//ph=2��1�����ֻ��װ��̹�˻�ִ��
	if (m_PH == 2)
	{
		m_diretion[0]->operator=("armor2D.png");
		m_diretion[1]->operator=("armor2U.png");
		m_diretion[2]->operator=("armor2D.png");
		m_diretion[3]->operator=("armor2L.png");
		m_diretion[4]->operator=("armor2R.png");
		this->setDisplayFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName(m_diretion[m_moveDirection]->getCString()));
	}
	else if(m_PH==1)
	{
		m_diretion[0]->operator=("armor1D.png");
		m_diretion[1]->operator=("armor1U.png");
		m_diretion[2]->operator=("armor1D.png");
		m_diretion[3]->operator=("armor1L.png");
		m_diretion[4]->operator=("armor1R.png");
		this->setDisplayFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName(m_diretion[m_moveDirection]->getCString()));
	}
	else if (m_PH<=0)
	{		
		this->blowUp();
	}
}
void EnemyTank::startShoot()
{
	schedule(schedule_selector(EnemyTank::shoot), 0.5);
}
void EnemyTank::stopShoot()
{
	unschedule(schedule_selector(EnemyTank::shoot));
}
void EnemyTank::blowUp()
{
	this->tankMoveStop();
	this->stopShoot();
	SoundManager::playBlowUpSound();

	//���ӷ���
	GameScene::getMessageManager()->changeScorePic(this->m_score);

	//����Ǻ�ɫ̹�������������������
	if (this->getName() == "normalTank_R" || this->getName() == "armor3Tank_R" || this->getName() == "speedTank_R")
	{
		GameScene::getItemManager()->createItem();
	}

	delete m_diretion[0];
	delete m_diretion[1];
	delete m_diretion[2];
	delete m_diretion[3];
	delete m_diretion[4];

	EnemyManager::dieTankCount(this->m_tankType);


	this->getPhysicsBody()->removeFromWorld();
	auto animation = Animation::create();
	animation->addSpriteFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName("tankbomb_01.png"));
	animation->addSpriteFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName("tankbomb_02.png"));
	animation->addSpriteFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName("tankbomb_03.png"));
	animation->addSpriteFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName("tankbomb_04.png"));
	animation->addSpriteFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName("tankbomb_05.png"));
	
	animation->setDelayPerUnit(0.05);//��������֡����ʱ����
	animation->setLoops(1);//�����Ƿ�ѭ������,-1����ѭ��,����n����n��,0������
	animation->setRestoreOriginalFrame(false);//���ö�����������Ƿ�ص���һ֡
	auto _blowUp = Animate::create(animation);


	auto _func2 = CallFunc::create([this] {
		this->removeFromParent(); });

	auto _act = Sequence::create(_blowUp, _func2, nullptr);
	this->runAction(_act);

	//this->removeFromParent();

}
