#include"GameMenu.h"
#include "GameScene.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include "SimpleAudioEngine.h"
#include"SoundManager.h"
#include"HeroManager.h"
#include"EnemyManager.h"
#include"HeroTank.h"
#include"AboutScene.h"
#include"MessageManager.h"


USING_NS_CC;
using namespace cocostudio::timeline;
using namespace cocos2d::ui;
using namespace CocosDenshion;

Scene* GameMenu::createScene()
{
	auto _scene = Scene::create();
	auto _layer = GameMenu::create();
	_scene->addChild(_layer);
	return _scene;
}
bool GameMenu::init()
{
	if (!Layer::init())
	{
		return false;
	}
	SoundManager::stopAllSounds();

	//Ԥ������Դ��������
	this->preloadSources();
	this->dataInit();
	

    //����˵�ͼ��
	auto menuLayer = CSLoader::createNode("GameMenu.csb");
	this->addChild(menuLayer);

	//��ȡ��ť
	m_panel = (Layout*)menuLayer->getChildByName("Panel");
	m_startButton = (Button*)Helper::seekWidgetByName(m_panel, "StartButton");
	m_oboutButton = (Button*)Helper::seekWidgetByName(m_panel, "AboutButton");
	m_exitButton = (Button*)Helper::seekWidgetByName(m_panel, "ExitButton");

	//���¼�
	m_startButton->addTouchEventListener(CC_CALLBACK_2(GameMenu::startGame, this));
	m_oboutButton->addTouchEventListener(CC_CALLBACK_2(GameMenu::oboutGame, this));
	m_exitButton->addTouchEventListener(CC_CALLBACK_2(GameMenu::exitGame, this));







	return true;
}
void GameMenu::preloadSources()
{
	//Ԥ����ͼƬ��Դ���ڴ�
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("tank.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("item.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("tiles.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("blowUp.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("bomb.plist");

	//Ԥ������Ч��Դ
	auto audioengine = SimpleAudioEngine::getInstance();
	/*audioengine->preloadEffect("gameStart.mp3");
	audioengine->preloadEffect("shoot.mp3");
	audioengine->preloadEffect("gainItem.mp3");
	audioengine->preloadEffect("createItem.mp3");
	audioengine->preloadEffect("bang.mp3");
	audioengine->preloadEffect("gainLife.mp3");
	audioengine->preloadEffect("gainGrenade.mp3");
	audioengine->preloadBackgroundMusic("move.mp3");
	audioengine->preloadEffect("count.mp3");*/

	audioengine->preloadEffect("gameStart.wav");
	audioengine->preloadEffect("shoot.wav");
	audioengine->preloadEffect("gainItem.wav");
	audioengine->preloadEffect("createItem.wav");
	audioengine->preloadEffect("bang.wav");
	audioengine->preloadEffect("gainLife.wav");
	audioengine->preloadBackgroundMusic("move.wav");
	audioengine->preloadEffect("gainGrenade.wav");
	
}
void GameMenu::unloadSources()
{
	SpriteFrameCache::getInstance()->destroyInstance();
	SimpleAudioEngine::getInstance()->end();
}
void GameMenu::startGame(cocos2d::Object* pSender, Widget::TouchEventType type)
{
	switch (type)
	{
	case Widget::TouchEventType::BEGAN:
		break;
	case Widget::TouchEventType::MOVED:
		break;
	case Widget::TouchEventType::ENDED:
		Director::getInstance()->replaceScene(TransitionFade::create(0.1f, GameScene::createScene()));
		break;
	case Widget::TouchEventType::CANCELED:
		break;
	default:
		break;
	}
}
void GameMenu::oboutGame(cocos2d::Object* pSender, Widget::TouchEventType type)
{
	switch (type)
	{
	case Widget::TouchEventType::BEGAN:
		break;
	case Widget::TouchEventType::MOVED:
		break;
	case Widget::TouchEventType::ENDED:
		Director::getInstance()->replaceScene(TransitionFade::create(0.1f, AboutScene::createScene()));
		break;
	case Widget::TouchEventType::CANCELED:
		break;
	default:
		break;
	}
}
void GameMenu::exitGame(cocos2d::Object* pSender, Widget::TouchEventType type)
{
	switch (type)
	{
	case Widget::TouchEventType::BEGAN:
		break;
	case Widget::TouchEventType::MOVED:
		break;
	case Widget::TouchEventType::ENDED:
		this->unloadSources();
		Director::getInstance()->end();
		break;
	case Widget::TouchEventType::CANCELED:
		break;
	default:
		break;

	}
}
void GameMenu::dataInit()
{
	HeroManager::dataInit();
	HeroTank::dataInit();
	GameScene::dataInit();
	EnemyManager::dataInit();
	MessageManager::dataInit();
}
