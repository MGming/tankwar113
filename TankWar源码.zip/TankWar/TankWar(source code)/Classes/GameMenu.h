/*----------------------------------------------------------------------------------------
����:   <FC̹�˴�ս>
����:   Cocos2dx-3.10
ʱ��:   2018.9
����:   ����
����:   lm-email@qq.com
-----------------------------------------------------------------------------------------*/

#pragma once
#include "cocos2d.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"


USING_NS_CC;
using namespace cocostudio::timeline;
using namespace cocos2d::ui;

class GameMenu:public cocos2d::Layer
{
private:
	Layout * m_panel;
	Button* m_startButton;
	Button* m_oboutButton;
	Button* m_exitButton;
	bool m_effectSwitch;

public:
	static Scene* createScene();
	bool init();
	void dataInit();                 //�������ݳ�ʼ��
	void preloadSources();            //Ԥ������Դ
	void unloadSources();             //�ͷ���Դ
	CREATE_FUNC(GameMenu);

	void startGame(cocos2d::Object* pSender, Widget::TouchEventType type);
	void oboutGame(cocos2d::Object* pSender, Widget::TouchEventType type);
	void exitGame(cocos2d::Object* pSender, Widget::TouchEventType type);

};
