/***************************************
����:LM
����:2018.10
����:lm-email@qq.com
�ٶ�����:lmbd12
csdn����:https://blog.csdn.net/qq_41865229
��֪:�������ѧϰ,��������������;
***********************************/
#include "cocos2d.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include"GameScene.h"
#include"HeroBullet.h"
#include"MapLayer.h"
#include"HeroTank.h"
#include"EnemyTank.h"
#include "SimpleAudioEngine.h"

USING_NS_CC;
using namespace cocostudio::timeline;
using namespace cocos2d::ui;
using namespace CocosDenshion;


//��̬��������ʱ���븳ֵ�������ڴ����,�Ҿ�̬���������⸳ֵ
MapManager* GameScene::m_mapManager=nullptr;
BulletManager* GameScene::m_bulletManager=nullptr;
HeroManager* GameScene::m_heroManager = nullptr;
EnemyManager* GameScene::m_enemyManager=nullptr;
ItemManager* GameScene::m_itemManager=nullptr;
MessageManager* GameScene::m_messageManager = nullptr;

int GameScene::m_round = 0;
Scene* GameScene::createScene()
{
	m_round += 1;
	if (m_round >= 50)                  //����49�غ�ص���һ��
	{
		m_round = 1;
	}
	//log("round=%d", m_round);
	auto scene = Scene::createWithPhysics();
	scene->getPhysicsWorld()->setGravity(Vect(0, 0));

	//�������Ի�ͼ
	//scene->getPhysicsWorld()->setDebugDrawMask(PhysicsWorld::DEBUGDRAW_ALL);

	auto layer = GameScene::create();
	scene->addChild(layer);
	return scene;
}
bool GameScene::init()
{
	if (!Layer::init())
	{
		return false;
	}

	//�ȷſ�������,�ٷű�������
	auto _func1 = CallFunc::create([] {SoundManager::playGameStartSound(); });
	auto _func2 = CallFunc::create([] {SoundManager::playBgSound(); });
	auto _dt = DelayTime::create(5);
	auto _act1 = Sequence::create(_func1,_dt, _func2, nullptr);
	this->runAction(_act1);
	
	

	auto _winSize = Director::getInstance()->getWinSize();

	DrawPrimitives::setDrawColor4B(25, 55, 0, 205);
	DrawPrimitives::setPointSize(50);
	Vec2 _vert[] = { Vec2((_winSize.width - _winSize.height)*0.5,0),Vec2((_winSize.width - _winSize.height)*0.5,_winSize.height),Vec2(_winSize.width - (_winSize.width - _winSize.height)*0.5,_winSize.height),Vec2(_winSize.width - (_winSize.width - _winSize.height)*0.5,0) };
	DrawPrimitives::drawPoly(_vert, 4, false);
	

	/**������Ϣ��������**/
	m_messageManager = MessageManager::create();
	this->addChild(m_messageManager, 5);


	/**������Ƭ��ͼ������**/
	m_mapManager = MapManager::create();
	m_mapManager->setPositionX((_winSize.width - _winSize.height)*0.5);
	this->addChild(m_mapManager, 3);

	/**��������ӵ�������**/
	m_bulletManager = BulletManager::create();
	m_bulletManager->setPositionX((_winSize.width - _winSize.height)*0.5);
	this->addChild(m_bulletManager, 0);

	/**�����ҷ�̹�˹�����**/
	m_heroManager = HeroManager::create();
	m_heroManager->setPositionX((_winSize.width - _winSize.height)*0.5);
	this->addChild(m_heroManager,1);

	/**����з�̹�˹�����**/
	m_enemyManager = EnemyManager::create();
	m_enemyManager->setPositionX((_winSize.width - _winSize.height)*0.5);
	this->addChild(m_enemyManager, 2);

	/**����ӳɵ��߹�����**/
	m_itemManager = ItemManager::create();
	m_itemManager->setPositionX((_winSize.width - _winSize.height)*0.5);
	this->addChild(m_itemManager, 4);


	


	//������ײ�Ӵ��¼�����
	auto _contactListener = EventListenerPhysicsContact::create();
	_contactListener->onContactBegin = CC_CALLBACK_1(GameScene::dealWithContact, this);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(_contactListener, this);


	//���봥���¼�����
	auto _touchListener = EventListenerTouchOneByOne::create();
	_touchListener->onTouchBegan = CC_CALLBACK_2(GameScene::onTouchBegan, this);
	_touchListener->setSwallowTouches(0);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(_touchListener, this);



	return true;
}

bool GameScene::onTouchBegan(Touch* touch, Event* event)
{
	auto m_map = m_mapManager->getMapLayer()->getMap();
	auto touchPos = touch->getLocation();
	int gid = 0;
	auto _mapSize = m_map->getContentSize();
	auto _tileSize = m_map->getTileSize();
	auto _layer = m_map->getLayer("layer1");
	int Y = (int)(_mapSize.height - touchPos.y) / _tileSize.height;
	int X = (int)(touchPos.x / _tileSize.width);
	gid = _layer->getTileGIDAt(Vec2(X, Y));
	//log("x=%d,y=%d,gid=%d", X, Y, gid);

	return true;
}

bool GameScene::dealWithContact(PhysicsContact& contact)
{

	//log("contact");
	auto node1 = contact.getShapeA()->getBody()->getNode();
	auto node2 = contact.getShapeB()->getBody()->getNode();

	if (!node1 || !node2)
		return false;
	auto tag1 = node1->getTag();
	auto tag2 = node2->getTag();

	//log("tag1=%d,tag2=%d", tag1, tag2);
	//�ҷ��ӵ����ϰ��﷢����ײ
	if ((tag1 == HERO_BULLET_TAG && tag2 == TILE_TAG) || (tag2 == HERO_BULLET_TAG && tag1 == TILE_TAG))
	{
		//�ӵ���ש����ײ
		if (node1->getName() == "brick" &&node2->getName() == "heroBullet")
		{
			node1->removeFromParent();
			((HeroBullet*)node2)->getHurt(1);
		}
		else if (node2->getName() == "brick" &&node1->getName() == "heroBullet")
		{
			((HeroBullet*)node1)->getHurt(1);
			node2->removeFromParent();
		}

		//�ӵ��͸�����ײ
		else if (node1->getName() == "steel" &&node2->getName() == "heroBullet")
		{
			//���񵽵���ʹ�ӵ��������ڵ���3���ܴ������
			if(((HeroBullet*)node2)->getBulletPower()>=3)
			node1->removeFromParent();

			((HeroBullet*)node2)->getHurt(2);
		}
		else if (node2->getName() == "steel" &&node1->getName() == "heroBullet")
		{			
			//���񵽵���ʹ�ӵ��������ڵ���3���ܴ������
			if (((HeroBullet*)node1)->getBulletPower() >= 3)
				node2->removeFromParent();

			((HeroBullet*)node1)->getHurt(2);
		}


	}
	//�з��ӵ����ϰ��﷢����ײ
	else if ((tag1 == ENEMY_BULLET_TAG && tag2 == TILE_TAG) || (tag2 == ENEMY_BULLET_TAG && tag1 == TILE_TAG))
	{
		//�ӵ���ש����ײ
		if (node1->getName() == "brick" &&node2->getName() == "enemyBullet")
		{
			node1->removeFromParent();
			((EnemyBullet*)node2)->blowUp();
		}
		else if (node2->getName() == "brick" &&node1->getName() == "enemyBullet")
		{
			((EnemyBullet*)node1)->blowUp();
			node2->removeFromParent();
		}

		//�ӵ��͸�����ײ
		else if (node1->getName() == "steel" &&node2->getName() == "enemyBullet")
		{
			((EnemyBullet*)node2)->blowUp();
		}
		else if (node2->getName() == "steel" &&node1->getName() == "enemyBullet")
		{
			((EnemyBullet*)node1)->blowUp();
		}
	}
	//�з��ӵ����ҷ��ӵ�������ײ
	else if ((tag1 == ENEMY_BULLET_TAG && tag2 ==HERO_BULLET_TAG) || (tag2 == ENEMY_BULLET_TAG && tag1 == HERO_BULLET_TAG))
	{
		if (tag1 == ENEMY_BULLET_TAG && tag2 == HERO_BULLET_TAG)
		{
			((EnemyBullet*)node1)->blowUp();
			((HeroBullet*)node2)->blowUp();
		}
		else if (tag2 == ENEMY_BULLET_TAG && tag1 == HERO_BULLET_TAG)
		{
			((HeroBullet*)node1)->blowUp();
			((EnemyBullet*)node2)->blowUp();
		}
	}
	//�з�̹�˺��ҷ��ӵ�������ײ
	else if ((tag1 == ENEMY_TAG && tag2 == HERO_BULLET_TAG) || (tag2 == ENEMY_TAG && tag1 == HERO_BULLET_TAG))
	{
		//log("enemy&&bullet");
		if (tag2 == ENEMY_TAG && tag1 == HERO_BULLET_TAG)
		{
			((HeroBullet*)node1)->blowUp();
			((EnemyTank*)node2)->getHurt(((HeroBullet*)node1)->getBulletPower());

		}
		else if (tag1 == ENEMY_TAG && tag2 == HERO_BULLET_TAG)
		{
			((EnemyTank*)node1)->getHurt(((HeroBullet*)node1)->getBulletPower());
			((HeroBullet*)node2)->blowUp();
		}
	}
	//�з��ӵ����ҷ�̹�˷�����ײ
	else if ((tag1 == ENEMY_BULLET_TAG && tag2 == HERO_TAG) || (tag2 == ENEMY_BULLET_TAG && tag1 == HERO_TAG))
	{
		//log("hero&&bullet");
		if (tag2 == ENEMY_BULLET_TAG && tag1 == HERO_TAG)
		{
			((HeroTank*)node1)->getHurt(1);
			((EnemyBullet*)node2)->blowUp();
		}
		else if (tag1 == ENEMY_BULLET_TAG && tag2 == HERO_TAG)
		{
			((EnemyBullet*)node1)->blowUp();
			((HeroTank*)node2)->getHurt(1);
		}
	}
	//�ҷ�̹�˺͵��߷�����ײ
	else if ((tag1 == HERO_TAG && tag2 == ITEM_TAG) || (tag2 == HERO_TAG && tag1 == ITEM_TAG))
	{
		if (tag1 == HERO_TAG && tag2 == ITEM_TAG)
		{			
			((HeroTank*)node1)->getItem(node2->getName());
			node2->removeFromParent();
		}
		else if (tag2 == HERO_TAG && tag1 == ITEM_TAG)
		{
			((HeroTank*)node2)->getItem(node1->getName());
			node1->removeFromParent();
		}
		//log("hero&&item");
	}

	//�ҷ��ӵ����ϼҷ�����ײ
	if ((tag1 == HERO_BULLET_TAG && tag2 == HOME_TAG) || (tag2 == HERO_BULLET_TAG && tag1 == HOME_TAG))
	{
		//�ӵ���ש����ײ
		if (tag2 == HERO_BULLET_TAG && tag1 == HOME_TAG)
		{
			((HeroBullet*)node2)->blowUp();
			GameScene::getMapManager()->getMapLayer()->destoryHome();
		}
		else if (tag1 == HERO_BULLET_TAG && tag2 == HOME_TAG)
		{
			((HeroBullet*)node1)->blowUp();
			GameScene::getMapManager()->getMapLayer()->destoryHome();
		}
	}

	//�з��ӵ����ϼҷ�����ײ
	if ((tag1 == ENEMY_BULLET_TAG && tag2 == HOME_TAG) || (tag2 == ENEMY_BULLET_TAG && tag1 == HOME_TAG))
	{
		//�ӵ���ש����ײ
		if (tag2 == ENEMY_BULLET_TAG && tag1 == HOME_TAG)
		{
			GameScene::getMapManager()->getMapLayer()->destoryHome();
			((EnemyBullet*)node2)->blowUp();
		}
		else if (tag1 == ENEMY_BULLET_TAG && tag2 == HOME_TAG)
		{
			((EnemyBullet*)node1)->blowUp();
			GameScene::getMapManager()->getMapLayer()->destoryHome();
		}
	}
	return true;
}
void GameScene::dataInit()
{

	m_round =0;
}