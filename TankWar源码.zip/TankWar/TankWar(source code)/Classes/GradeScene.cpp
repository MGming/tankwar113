#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include "SimpleAudioEngine.h"
#include"GradeScene.h"
#include"SoundManager.h"
#include"GameMenu.h"
#include "GameScene.h"

USING_NS_CC;
using namespace cocostudio::timeline;
using namespace cocos2d::ui;
using namespace CocosDenshion;
int GradeScene::m_armorN = 0;
int GradeScene::m_speedN = 0;
int GradeScene::m_shootN = 0;
int GradeScene::m_normalN = 0;

Scene* GradeScene::createScene(int normalN, int speedN, int shootN, int armorN)
{
	m_normalN = normalN;
	m_speedN = speedN;
	m_shootN = shootN;
	m_armorN = armorN;
	auto _scene = Scene::create();
	auto _layer = GradeScene::create();
	_scene->addChild(_layer);
	return _scene;
}
bool GradeScene::init()
{
	if (!Layer::init())
	{
		return false;
	}

	SoundManager::stopAllSounds();

	//��ͣҳ��ͼ��
	m_gradeLayer = CSLoader::createNode("GradeScene.csb");
	this->addChild(m_gradeLayer, 1);

	m_panel = (Layout*)m_gradeLayer->getChildByName("Panel");
	m_normalSText = (Text*)Helper::seekWidgetByName(m_panel, "normalS");
	m_normalNText = (Text*)Helper::seekWidgetByName(m_panel, "normalN");
	m_speedSText = (Text*)Helper::seekWidgetByName(m_panel, "speedS");
	m_speedNText = (Text*)Helper::seekWidgetByName(m_panel, "speedN");
	m_armorSText= (Text*)Helper::seekWidgetByName(m_panel, "armorS");
	m_armorNText = (Text*)Helper::seekWidgetByName(m_panel, "armorN");
	m_shootSText= (Text*)Helper::seekWidgetByName(m_panel, "shootS");
	m_shootNText = (Text*)Helper::seekWidgetByName(m_panel, "shootN");
	m_totalSText = (Text*)Helper::seekWidgetByName(m_panel, "totalS");
	m_roundText= (Text*)Helper::seekWidgetByName(m_panel, "round");

	m_normalSText->setVisible(false);
	m_normalNText->setVisible(false);
	m_speedSText->setVisible(false);
	m_speedNText->setVisible(false);
	m_armorSText->setVisible(false);
	m_armorNText->setVisible(false);
	m_shootSText->setVisible(false);
	m_shootNText->setVisible(false);
	m_totalSText->setVisible(false);

	if ((this->m_normalN + this->m_speedN + this->m_shootN + this->m_armorN) == 20)
		m_isWin = 1;
	else
		m_isWin = 0;

	this->showGrade();
	return true;

}
void GradeScene::showGrade()
{

	char _round[5];
	sprintf(_round, "%d", GameScene::m_round);
	m_roundText->setText(_round);

	auto _func1 = CallFunc::create([this] {
		SoundManager::playCountSound();
		m_normalNText->setVisible(true);
		char _str[15];
		sprintf(_str, "%d", this->m_normalN);
		this->m_normalNText->setText(_str);
	
	});
	auto _func2 = CallFunc::create([this] {

		SoundManager::playCountSound();
		m_normalSText->setVisible(true);
		char _str[15];
		sprintf(_str, "%d", this->m_normalN*100);
		this->m_normalSText->setText(_str);
	
	});
	auto _func3 = CallFunc::create([this] {

		SoundManager::playCountSound();
		m_speedNText->setVisible(true);
		char _str[15];
		sprintf(_str, "%d", this->m_speedN);
		this->m_speedNText->setText(_str);

	});
	auto _func4 = CallFunc::create([this] {

		SoundManager::playCountSound();
		m_speedSText->setVisible(true);
		char _str[15];
		sprintf(_str, "%d", this->m_speedN*200);
		this->m_speedSText->setText(_str);

	});
	auto _func5 = CallFunc::create([this] {

		SoundManager::playCountSound();
		m_shootNText->setVisible(true);
		char _str[15];
		sprintf(_str, "%d", this->m_shootN);
		this->m_shootNText->setText(_str);

	});
	auto _func6 = CallFunc::create([this] {

		SoundManager::playCountSound();
		m_shootSText->setVisible(true);
		char _str[15];
		sprintf(_str, "%d", this->m_shootN*300);
		this->m_shootSText->setText(_str);

	});
	auto _func7 = CallFunc::create([this] {

		SoundManager::playCountSound();
		m_armorNText->setVisible(true);
		char _str[15];
		sprintf(_str, "%d", this->m_armorN);
		this->m_armorNText->setText(_str);

	});
	auto _func8 = CallFunc::create([this] {

		SoundManager::playCountSound();
		m_armorSText->setVisible(true);
		char _str[15];
		sprintf(_str, "%d", this->m_armorN*400);
		this->m_armorSText->setText(_str);

	});
	auto _func9 = CallFunc::create([this]{

		SoundManager::playCountSound();
		m_totalSText->setVisible(true);
		char _str[15];
		sprintf(_str, "%d", this->m_normalN * 100+this->m_speedN * 200+this->m_shootN * 300+this->m_armorN * 400);
		this->m_totalSText->setText(_str);
		//log("func9");
	});
	auto _func10 = CallFunc::create([this] {

		if(this->m_isWin==0)
		    Director::getInstance()->replaceScene(TransitionFade::create(0.1f, GameMenu::createScene()));

		else if (this->m_isWin ==1)
			Director::getInstance()->replaceScene(TransitionFade::create(0.1f, GameScene::createScene()));

	});
	auto _dt = DelayTime::create(0.5);
	auto _show = Sequence::create(_func1,_dt, _func2, _dt, _func3, _dt, _func4, _dt, _func5, _dt, _func6, _dt, _func7, _dt, _func8, _dt, _func9, _dt, _func10, _dt, nullptr);
	this->runAction(_show);
}