#pragma once
#include "cocos2d.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"

USING_NS_CC;
using namespace cocostudio::timeline;
using namespace cocos2d::ui;
class GradeScene :public Layer
{
private:
	Node * m_gradeLayer;
	Layout* m_panel;
	static int m_normalN;
	static int m_speedN;
	static int m_shootN;
	static int m_armorN;
	Text* m_normalSText;
	Text* m_normalNText;
	Text* m_speedSText;
	Text* m_speedNText;
	Text* m_armorSText;
	Text* m_armorNText;
	Text* m_shootSText;
	Text* m_shootNText;
	Text* m_totalSText;
	Text* m_roundText;
	bool m_isWin;


public:
	static Scene* createScene(int normalN,int speedN,int shootN,int armorN );
	bool init();
	CREATE_FUNC(GradeScene);
	void showGrade();



};
