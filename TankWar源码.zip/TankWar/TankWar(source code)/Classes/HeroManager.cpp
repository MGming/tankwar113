#include "cocos2d.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include"HeroManager.h"
#include"HeroBullet.h"
#include"BulletManager.h"
#include"GameScene.h"

USING_NS_CC;
using namespace cocostudio::timeline;
using namespace cocos2d::ui;

int HeroManager::m_tankLife = 5;

bool HeroManager::init()
{
	if (!Layer::init())
	{
		return false;
	}

	this->createHeroTank();         //�����ҷ�̹��
	GameScene::getMessageManager()->changeLifePic(GameScene::getHeroManager()->getTankLife());

	return true;
}
void HeroManager::createHeroTank()
{
	//�ӵ�ͼ�����������ҵ��ҷ�̹�˳���λ��
	auto _objLayer1 = GameScene::getMapManager()->getMapLayer()->getMap()->getObjectGroup("objLayer1");
	auto _birthPlace = _objLayer1->getObject("heroBirthPlace1");
	m_heroBirthPos = Vec2(_birthPlace["x"].asFloat(), _birthPlace["y"].asFloat());

	m_heroTank = HeroTank::create();	      //�����ҷ�̹�˲����뵽�ҷ�̹�˹�����
	m_heroTank->setAnchorPoint(Vec2(0.5, 0.5));
	m_heroTank->setPosition(m_heroBirthPos);

	this->addChild(m_heroTank);

	//������������
	auto _keyboardListener = EventListenerKeyboard::create();
	_keyboardListener->onKeyReleased = CC_CALLBACK_2(HeroManager::onKeyReleased, this);
	_keyboardListener->onKeyPressed = CC_CALLBACK_2(HeroManager::onKeyPressed, this);

	//�����ȼ��󶨸��ҷ�̹��,����̹���������������ͻ�ȡ��
	_eventDispatcher->addEventListenerWithSceneGraphPriority(_keyboardListener, m_heroTank);
	

	return;
}
void HeroManager::onEnter()
{
	Layer::onEnter();
	
}
void HeroManager::onKeyReleased(EventKeyboard::KeyCode keyCode, Event* event)
{
	if (this->getChildrenCount() == 0)
		return;

	//�ͷŷ����̹��ֹͣ�ƶ�
	if (keyCode == EventKeyboard::KeyCode::KEY_SPACE)
	{
		return;
	}
	  m_heroTank->tankMoveStop();

}
void HeroManager::onKeyPressed(EventKeyboard::KeyCode keyCode, Event* event)
{	

	if (this->getChildrenCount() == 0)
		return;


	//log("press");
	//���ݰ����ļ�ֵ���÷���
	switch (keyCode)
	{
	case EventKeyboard::KeyCode::KEY_UP_ARROW:
		m_moveDirection = 1;
		m_bulletDirection = 1;
		//log("up");
		break;
	case EventKeyboard::KeyCode::KEY_DOWN_ARROW:
		m_moveDirection = 2;
		m_bulletDirection = 2;
		//log("down");
		break;
	case EventKeyboard::KeyCode::KEY_LEFT_ARROW:
		m_moveDirection = 3;
		m_bulletDirection = 3;
		//log("left");
		break;
	case EventKeyboard::KeyCode::KEY_RIGHT_ARROW:
		m_moveDirection = 4;
		m_bulletDirection = 4;
		//log("right");
		break;
	case EventKeyboard::KeyCode::KEY_SPACE:
	{
		m_heroTank->shoot();
		//log("shoot");
	}
	    return;
	default:
		return;

	}
	//��ס�����̹�˳����ƶ�
	m_heroTank->tankMoveWithDirection(m_moveDirection);
}
HeroTank* HeroManager::getHeroTank()
{
	if (this->getChildrenCount() == 1)
		return m_heroTank;
	else
		return nullptr;

}
void HeroManager::heroUpMove()
{
	m_moveDirection = 1;
	m_bulletDirection = 1;
	m_heroTank->tankMoveWithDirection(m_moveDirection);
}
void HeroManager::heroDownMove()
{
	m_moveDirection = 2;
	m_bulletDirection = 2;
	m_heroTank->tankMoveWithDirection(m_moveDirection);
}
void HeroManager::heroLeftMove()
{
	m_moveDirection = 3;
	m_bulletDirection = 3;
	m_heroTank->tankMoveWithDirection(m_moveDirection);
}
void HeroManager::heroRightMove()
{
	m_moveDirection = 4;
	m_bulletDirection = 4;
	m_heroTank->tankMoveWithDirection(m_moveDirection);
}
void HeroManager::changeTankLife(int dL)
{ 
	m_tankLife += dL;
	GameScene::getMessageManager()->changeLifePic(GameScene::getHeroManager()->getTankLife());
}
void HeroManager::dataInit()
{
	HeroManager::m_tankLife = 5;
}