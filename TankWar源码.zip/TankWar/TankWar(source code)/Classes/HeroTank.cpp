#include "cocos2d.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include"HeroTank.h"
#include"GameScene.h"
#include"EnemyTank.h"
#include"SoundManager.h"
#include"Item.h"
USING_NS_CC;
using namespace cocostudio::timeline;
using namespace cocos2d::ui;


float HeroTank::m_bulletVelocity=200;                //�ӵ��ٶ�
int HeroTank::m_bulletPower=1;                      //�ӵ�����
bool HeroTank::m_boatSwitch=false;                  //�ɺӿ���
//int HeroTank::m_life=5;                           //̹��������

bool HeroTank::init()
{
	if (!Sprite::init())
	{
		return false;
	}
	this->initWithSpriteFrameName("armor1U.png");	
	this->tankBear();
	this->m_spadeCount = 0;
	return true;
}
void HeroTank::onEnter()
{
	Sprite::onEnter();
	
	
}
void HeroTank::tankBack()
{
	this->m_getHurtSwitch = false;
	this->m_moveDirection = 1;
	this->setDisplayFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName("armor1U.png"));

	//̹�˳�����λ��
	auto _objLayer1 = GameScene::getMapManager()->getMapLayer()->getMap()->getObjectGroup("objLayer1");
	auto _birthPlace = _objLayer1->getObject("heroBirthPlace1");
	auto _heroBirthPos = Vec2(_birthPlace["x"].asFloat(), _birthPlace["y"].asFloat());
	this->setPosition(_heroBirthPos);

	//�޵�״̬����Ч
	auto animation = Animation::create();
	animation->addSpriteFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName("shield1.png"));
	animation->addSpriteFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName("shield2.png"));
	animation->setDelayPerUnit(0.1);//��������֡����ʱ����
	animation->setLoops(-1);//�����Ƿ�ѭ������,-1����ѭ��,����n����n��,0������
	animation->setRestoreOriginalFrame(true);//���ö�����������Ƿ�ص���һ֡
	auto shield = Animate::create(animation);
	auto _shieldSprite = Sprite::create();
	_shieldSprite->setPosition(Vec2(30, 30));
	this->addChild(_shieldSprite);
	_shieldSprite->runAction(shield);
	_shieldSprite->setScale(2.5);

	//�����������޵�
	auto _openGetHurt = CallFunc::create([this, _shieldSprite] {this->m_getHurtSwitch = true; _shieldSprite->removeFromParent();});
	auto _canMove = CallFunc::create([this, _heroBirthPos] { this->setPosition(_heroBirthPos); this->m_isCanMove = true; });
	auto _dt = DelayTime::create(4);
	auto _dt0 = DelayTime::create(1);
	auto _act = Sequence::create(_dt0, _canMove, _dt, _openGetHurt, nullptr);
	this->runAction(_act);

}
void HeroTank::tankBear()
{
	this->m_isCanMove = false;
	this->m_PH = 1;
	auto _tankHeroSize = this->getContentSize();
	float _ratio = 0.52;	
	this->setScale(_ratio);
	//this->setContentSize(_tankHeroSize*_ratio);
	this->m_shootSwitch = true;
	this->setName("heroTank");
	this->setTag(GameScene::NodeTag::HERO_TAG);
	this->m_moveStep = GameScene::getMapManager()->getMapLayer()->getMap()->getTileSize().height;
	this->m_isMoveing = false;
	//this->m_bulletVelocity = 200;
	//this->m_bulletPower = 1;
	this->m_getHurtSwitch = false;
	//this->m_boatSwitch = false;
	

	//��̹����һ��body�ӵ�����������,���������óߴ���Զ�����,�������ﲻ�ó�������ϵ��
	auto body = PhysicsBody::createBox(this->getContentSize(), PhysicsMaterial(10, 0, 0));
	body->setVelocity(Vec2(0, 0));
	body->setCategoryBitmask(GameScene::CategoryMaskBit::HERO_CATEGORYMASKBIT);
	body->setContactTestBitmask(GameScene::ContactMaskBit::HERO_CONTACTMASKBIT);
	body->setCollisionBitmask(GameScene::CollisionMaskBit::HERO_COLLISIONMASKBIT); //��������ײģ��
	this->setPhysicsBody(body);

	this->tankBack();          //̹�˻ص����
}
void HeroTank::tankMove(float dt)
{
	if (this->m_isCanMove == false)
		return; 

	m_moveVelocity =5;
	float _time=m_moveStep/(m_moveVelocity*m_moveStep );
	//���̹�˾��ε�����
	Rect _tankRect = this->getBoundingBox();
	float _x1 = _tankRect.getMinX();
	float _x2 = _tankRect.getMaxX();
	float _y1 = _tankRect.getMinY();
	float _y2 = _tankRect.getMaxY();
	float _stepX = 0;
	float _stepY = 0;
	Rect _moveRect;           //Ҫǰ����λ�õľ���

	if (m_moveDirection == 1)
	{
		this->setDisplayFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName("armor1U.png"));
		_stepY = m_moveStep;
		_moveRect.setRect(_x1 + _stepX, _y1 + _stepY, _x2 - _x1, _y2 - _y1);

		//���Ҫǰ����λ�õľ����Ƿ�����ϰ�
		if (!moveCollisionTest(_moveRect)&&m_isMoveing!=true)
		{
			this->m_isMoveing = true;
			auto _move = MoveBy::create(_time, Vec2(0,m_moveStep));
			auto _func = CallFunc::create([this]() {this->m_isMoveing = false; });
			auto _moveing = Sequence::create(_move, _func, nullptr);
			this->runAction(_moveing);
		}
	}
	else if (m_moveDirection == 2)
	{
		this->setDisplayFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName("armor1D.png"));
		_stepY = -m_moveStep;
		_moveRect.setRect(_x1 + _stepX, _y1 + _stepY, _x2 - _x1, _y2 - _y1);
		if (!moveCollisionTest(_moveRect) && m_isMoveing != true)
		{ 

			this->m_isMoveing = true;
			auto _move = MoveBy::create(_time, Vec2(0, -m_moveStep));
			auto _func = CallFunc::create([this]() {this->m_isMoveing = false; });
			auto _moveing = Sequence::create(_move, _func, nullptr);
			this->runAction(_moveing);
		}
	}
	else if (m_moveDirection == 3 )
	{
		this->setDisplayFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName("armor1L.png"));
		_stepX = -m_moveStep;
		_moveRect.setRect(_x1 + _stepX, _y1 + _stepY, _x2 - _x1, _y2 - _y1);
		if (!moveCollisionTest(_moveRect) && m_isMoveing != true)
		{
			this->m_isMoveing = true;
			auto _move = MoveBy::create(_time, Vec2(-m_moveStep,0));
			auto _func = CallFunc::create([this]() {this->m_isMoveing = false; });
			auto _moveing = Sequence::create(_move, _func, nullptr);
			this->runAction(_moveing);
		}
	}
	else if (m_moveDirection == 4 )
	{
		this->setDisplayFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName("armor1R.png"));
		_stepX = m_moveStep;
		_moveRect.setRect(_x1 + _stepX, _y1 + _stepY, _x2 - _x1, _y2 - _y1);
		if (!moveCollisionTest(_moveRect) && m_isMoveing != true)
		{ 
			this->m_isMoveing = true;
			auto _move = MoveBy::create(_time, Vec2(m_moveStep, 0));
			auto _func = CallFunc::create([this]() {this->m_isMoveing = false; });
			auto _moveing = Sequence::create(_move, _func, nullptr);
			this->runAction(_moveing);
		}
	}




}
void HeroTank::shoot()
{
	
	if (!this->getShootSwitch())        //����������Ϊfalse���ܷ����ӵ�
		return;

	this->setShootSwitch(false);
	//�����ӵ������뵽�ӵ���Ⱦ����
	auto bullet = HeroBullet::createBulletWithDVP(m_moveDirection,m_bulletVelocity,m_bulletPower);
	bullet->setPosition(this->getPosition());
	GameScene::getBulletManager()->getBulletList()->addChild(bullet);
	SoundManager::playShootSound();
}

bool HeroTank::moveCollisionTest(Rect rect)
{
	
	auto _map = GameScene::getMapManager()->getMapLayer()->getMap();
	auto _mapLayer1 = _map->getLayer("layer1");
	int _gid = 0;
	auto _winSize = Director::getInstance()->getWinSize();
	auto _mapSize = _map->getContentSize();
	auto _tileSize = _map->getTileSize();
	int _blankCount = 0;

	//��ΪTMX��ͼ������ԭ�������Ͻ�,���º����ҷֱ�Ϊxy��������,��cocos��������ϵԭ�������½�,����������Ҫ��Y������ת��ΪTMX��ͼ������
	float _minY = _mapSize.height - rect.getMinY();
	float _maxY = _mapSize.height - rect.getMaxY();

	//�����layer1�ϸõ㲻�ǿհ�λ��,������ϰ�

	//�˶�����λ�ú��̹�����½ǵ�
	_gid = _mapLayer1->getTileGIDAt(Vec2((int)(rect.getMinX() / _tileSize.width), (int)(_minY / _tileSize.height)));
	//log("gid=%d", _gid);
	if (_gid != 0 && fabs(_gid) < 1000)
	{
		auto _type = _map->getPropertiesForGID(_gid).asValueMap();
		if (_type["type"].asString() != "water")
			return true;
		else if (_type["type"].asString() == "water"&&m_boatSwitch == false)
			return true;
		else if (_type["type"].asString() == "water"&&m_boatSwitch == true)
			GameScene::getHeroManager()->setZOrder(4);
	}
	else
		_blankCount++;

	_gid = _mapLayer1->getTileGIDAt(Vec2((int)(rect.getMinX() / _tileSize.width), (int)(_minY / _tileSize.height)));
	//log("gid=%d", _gid);
	if (_gid != 0 && fabs(_gid)<1000)
	{
		auto _type = _map->getPropertiesForGID(_gid).asValueMap();
		if (_type["type"].asString() != "water")
			return true;
		else if (_type["type"].asString() == "water"&&m_boatSwitch == false)
			return true;
		else if (_type["type"].asString() == "water"&&m_boatSwitch == true)
			GameScene::getHeroManager()->setZOrder(4);
	}
	else
		_blankCount++;

	//�˶�����λ�ú��̹�����Ͻǵ�
	_gid = _mapLayer1->getTileGIDAt(Vec2((int)(rect.getMinX() / _tileSize.width), (int)(_maxY / _tileSize.height)));
	//log("gid=%d", _gid);
	if (_gid != 0 && fabs(_gid)<1000)
	{
		auto _type = _map->getPropertiesForGID(_gid).asValueMap();
		if (_type["type"].asString() != "water")
			return true;
		else if (_type["type"].asString() == "water"&&m_boatSwitch == false)
			return true;
		else if (_type["type"].asString() == "water"&&m_boatSwitch == true)
			GameScene::getHeroManager()->setZOrder(4);	
	}
	else
		_blankCount++;

	// �˶�����λ�ú��̹�����Ͻǵ�
	_gid = _mapLayer1->getTileGIDAt(Vec2((int)(rect.getMaxX() / _tileSize.width), (int)(_maxY / _tileSize.height)));
	//log("gid=%d", _gid);
	if (_gid != 0 && fabs(_gid)<1000)
	{
		auto _type = _map->getPropertiesForGID(_gid).asValueMap();
		if (_type["type"].asString() != "water")
			return true;
		else if (_type["type"].asString() == "water"&&m_boatSwitch == false)
			return true;
		else if (_type["type"].asString() == "water"&&m_boatSwitch == true)
			GameScene::getHeroManager()->setZOrder(4);
		
	}
	else
		_blankCount++;


	// �˶�����λ�ú��̹�����½ǵ�
	_gid = _mapLayer1->getTileGIDAt(Vec2((int)(rect.getMaxX() / _tileSize.width), (int)(_minY / _tileSize.height)));
	//log("gid=%d", _gid);
	if (_gid != 0 && fabs(_gid)<1000)
	{
		auto _type = _map->getPropertiesForGID(_gid).asValueMap();
		if (_type["type"].asString() != "water")
			return true;
		else if (_type["type"].asString() == "water"&&m_boatSwitch == false)
			return true;
		else if (_type["type"].asString() == "water"&&m_boatSwitch == true)
			GameScene::getHeroManager()->setZOrder(4);
			
	}
	else
		_blankCount++;

	// �˶�����λ�ú��̹�����нǵ�
	_gid = _mapLayer1->getTileGIDAt(Vec2((int)((rect.getMinX()+rect.getMaxX())*0.5 / _tileSize.width), (int)(_minY / _tileSize.height)));
	//log("gid=%d", _gid);
	if (_gid != 0 && fabs(_gid)<1000)
	{
		auto _type = _map->getPropertiesForGID(_gid).asValueMap();
		if (_type["type"].asString() != "water")
			return true;
		else if (_type["type"].asString() == "water"&&m_boatSwitch == false)
			return true;
		else if (_type["type"].asString() == "water"&&m_boatSwitch == true)
			GameScene::getHeroManager()->setZOrder(4);
		
	
	}
	else
		_blankCount++;

	// �˶�����λ�ú��̹�����нǵ�
	_gid = _mapLayer1->getTileGIDAt(Vec2((int)((rect.getMinX() + rect.getMaxX())*0.5 / _tileSize.width), (int)(_maxY / _tileSize.height)));
	//log("gid=%d", _gid);
	if (_gid != 0 && fabs(_gid)<1000)
	{
		auto _type = _map->getPropertiesForGID(_gid).asValueMap();
		if (_type["type"].asString() != "water")
			return true;
		else if (_type["type"].asString() == "water"&&m_boatSwitch == false)
			return true;
		else if (_type["type"].asString() == "water"&&m_boatSwitch == true)
			GameScene::getHeroManager()->setZOrder(4);
		
	}
	else
		_blankCount++;

	// �˶�����λ�ú��̹�����нǵ�
	_gid = _mapLayer1->getTileGIDAt(Vec2((int)(rect.getMinX() / _tileSize.width), (int)((_minY + _maxY)*0.5 / _tileSize.height)));
	//log("gid=%d", _gid);
	if (_gid != 0 && fabs(_gid)<1000)
	{
		auto _type = _map->getPropertiesForGID(_gid).asValueMap();
		if (_type["type"].asString() != "water")
			return true;
		else if (_type["type"].asString() == "water"&&m_boatSwitch == false)
			return true;
		else if (_type["type"].asString() == "water"&&m_boatSwitch == true)
			GameScene::getHeroManager()->setZOrder(4);
	
	}
	else
		_blankCount++;

	// �˶�����λ�ú��̹�����нǵ�
	_gid = _mapLayer1->getTileGIDAt(Vec2((int)(rect.getMaxX()/ _tileSize.width), (int)((_minY + _maxY)*0.5 / _tileSize.height)));
	//log("gid=%d", _gid);
	if (_gid != 0 && fabs(_gid)<1000)
	{
		auto _type = _map->getPropertiesForGID(_gid).asValueMap();
		if (_type["type"].asString() != "water")
			return true;
		else if (_type["type"].asString() == "water"&&m_boatSwitch == false)
			return true;
		else if (_type["type"].asString() == "water"&&m_boatSwitch == true)
			GameScene::getHeroManager()->setZOrder(4);
				
	}

	else
		_blankCount++;

	//̹�˴�ˮ����ȫ�߳�����,Z��ָ�Ϊ1
	if(_blankCount==9)
	GameScene::getHeroManager()->setZOrder(1);

	//����õ����,Ҳ���谭
	if (rect.getMinY() < 0 || rect.getMinX() < 0 || rect.getMaxX() > _winSize.height || rect.getMaxY() > _winSize.height)
		return true;

	//̹���谭
	if (isTankBlock(rect))
		return true;



	//ȫ���жϾ����谭,�谭Ϊ��
	//GameScene::getHeroManager()->setZOrder(1);
	return false;

}

void HeroTank::tankMoveWithDirection(int direction)
{
	//��ס��Ӧ����̹�˻�����ƶ�
	m_moveDirection = direction;
	schedule(schedule_selector(HeroTank::tankMove));
}
void HeroTank::tankMoveStop()
{
	//�ͷ���Ӧ����̹�˻�ֹͣ�ƶ�
	unschedule(schedule_selector(HeroTank::tankMove));
}

bool HeroTank::isTankBlock(Rect rect)
{
	auto _enemyTanks = GameScene::getEnemyManager()->getEnemyTankList()->getChildren();
	//�����з�̹��,�ж��ҷ�̹���Ƿ�������ײ
	for (auto& _enemy:_enemyTanks)
	{
		Rect _enemyRect=_enemy->getBoundingBox();
		if (_enemyRect.intersectsRect(rect))
			return true;
	}

	return false;
}
void HeroTank::getHurt(int hurt)
{
	//�޵�״̬�²��ܵ��˺�
	if (m_getHurtSwitch == false)
		return;

	int _hurt = hurt;
	m_PH -= hurt;

	//ph=2��1�����ֻ��װ��̹�˻�ִ��
	/*if (m_PH == 2)
	{
		m_diretion[0]->operator=("armor2D.png");
		m_diretion[1]->operator=("armor2D.png");
		m_diretion[2]->operator=("armor2D.png");
		m_diretion[3]->operator=("armor2D.png");
		m_diretion[4]->operator=("armor2D.png");
	}
	else if (m_PH == 1)
	{
		m_diretion[0]->operator=("armor1D.png");
		m_diretion[1]->operator=("armor1D.png");
		m_diretion[2]->operator=("armor1D.png");
		m_diretion[3]->operator=("armor1D.png");
		m_diretion[4]->operator=("armor1D.png");
	}
	*/
	if (m_PH <= 0)
	{
		GameScene::getHeroManager()->changeTankLife(-1);
		this->blowUp();

		/*
		if(GameScene::getHeroManager()->getTankLife()<=0)
		{ 
			this->blowUp();
		}
		else
		{
			SoundManager::playBlowUpSound();
			HeroTank::m_bulletVelocity = 200;                //�ӵ��ٶ�
			HeroTank::m_bulletPower = 1;                      //�ӵ�����
			HeroTank::m_boatSwitch = false;                  //�ɺӿ���
			this->tankBear();                          //�����ҷ�̹��
		}
		*/

	}
	


}
void HeroTank::getItem(string item)
{
	//���ӷ���
	GameScene::getMessageManager()->changeScorePic(100);
	m_item = item;
	if (m_item == "stopwatch")
	{
		this->stopwatchBuff();
	}
	if (m_item == "star")
	{
		
		this->starBuff();
	}
	if (m_item == "grenade")
	{
		this->grenadeBuff();
	}
	if (m_item == "spade")
	{
		//SoundManager::playGetItemSound();
		//this->spadeBuff();
	}
	if (m_item == "gun")
	{
		this->gunBuff();
	}
	if (m_item == "boat")
	{
		
		this->boatBuff();
	}
	if (m_item == "tankLife")
	{
		
		this->tankLifeBuff();
	}
	if (m_item == "helmet")
	{
		this->helmetBuff();
	}
	
}
void HeroTank::stopwatchBuff()
{
	SoundManager::playGetItemSound();
	int _time = 10;
	auto _enemys = GameScene::getEnemyManager()->getEnemyTankList()->getChildren();
	for (auto& _enemy : _enemys)
	{
		_enemy->stopActionByTag(Item::ItemType::STOPWATCH);
		auto _stop = CallFunc::create([_enemy]
		{
			((EnemyTank*)_enemy)->tankMoveStop();
			((EnemyTank*)_enemy)->stopShoot();
			GameScene::getEnemyManager()->stopAddTank();
		});
		auto _dt = DelayTime::create(_time);
		auto _star = CallFunc::create([_enemy, this]
		{			
				((EnemyTank*)_enemy)->tankMoveWithRandom();
				((EnemyTank*)_enemy)->startShoot();		
		});
	
		auto _action = Sequence::create(_stop, _dt, _star, nullptr);
		_action->setTag(Item::ItemType::STOPWATCH);
		_enemy->runAction(_action);
	}
	auto _starAddtank = CallFunc::create([this] {	GameScene::getEnemyManager()->startAddTank(); });
	auto _dt = DelayTime::create(_time);
	auto _addTankAction = Sequence::create(_dt, _starAddtank, nullptr);
	this->runAction(_addTankAction);
}
void HeroTank::starBuff()
{
	SoundManager::playGetItemSound();
	this->m_bulletVelocity = 400;
}
void HeroTank::grenadeBuff()
{

	SoundManager::playGainGrenadeSound();
	auto _enemys = GameScene::getEnemyManager()->getEnemyTankList()->getChildren();

	if (GameScene::getEnemyManager()->getEnemyTankList()->getChildrenCount() == 0)
		return;

	for (auto& _enemy : _enemys)
	{
		((EnemyTank*)_enemy)->blowUp();
	}
	
}
void HeroTank::helmetBuff()
{
	SoundManager::playGetItemSound();
	//�޵�
	this->m_getHurtSwitch = false;


	this->removeChildByName("shield");
	this->stopActionByTag(Item::ItemType::HELMET);
	auto animation = Animation::create();
	animation->addSpriteFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName("shield1.png"));
	animation->addSpriteFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName("shield2.png"));
	animation->setDelayPerUnit(0.1);//��������֡����ʱ����
	animation->setLoops(-1);//�����Ƿ�ѭ������,-1����ѭ��,����n����n��,0������
	animation->setRestoreOriginalFrame(true);//���ö�����������Ƿ�ص���һ֡
	auto shield = Animate::create(animation);
	auto _shieldSprite = Sprite::create();
	_shieldSprite->setPosition(Vec2(30, 30));
	_shieldSprite->setName("shield");
	this->addChild(_shieldSprite);
	_shieldSprite->runAction(shield);
	_shieldSprite->setScale(2.5);

	//15���Ӻ��޵�ȡ��
	auto _openGetHurt = CallFunc::create([this, _shieldSprite] {this->m_getHurtSwitch = true; _shieldSprite->removeFromParent(); });
	//auto _removeAnimation = CallFunc::create([this, _shieldSprite] { _shieldSprite->removeFromParent(); });
	auto _dt = DelayTime::create(15);
	auto _act = Sequence::create(_dt,_openGetHurt, nullptr);
	//_removeAnimation->setTag(Item::ItemType::HELMET);
	_act->setTag(Item::ItemType::HELMET);
	this->runAction(_act);
}
void HeroTank::gunBuff()
{
	SoundManager::playGetItemSound();
	this->m_bulletPower = 3;
}

void HeroTank::spadeBuff()
{
	
	//this->m_spadeCount+=1;
	//if (m_spadeCount % 2 != 0)
		GameScene::getMapManager()->getMapLayer()->addHomeSteelWall();
	//else
		//GameScene::getMapManager()->getMapLayer()->removeHomeSteelWall();
	/*
	auto _resume = CallFunc::create([] {
		_spadeCount = 0; 
		GameScene::getMapManager()->getMapLayer()->addHomeBrickWall();	
	});
	auto _dt = DelayTime::create(10);                                   //����ʱ��
	auto _act = Sequence::create(_dt,_resume,nullptr);
	this->runAction(_act);
	*/
}
void HeroTank::boatBuff()
{
	SoundManager::playGetItemSound();
	m_boatSwitch = true;
}
void HeroTank::tankLifeBuff()
{
	SoundManager::playGainLifeSound();
	GameScene::getHeroManager()->changeTankLife(1);
}
void HeroTank::dataInit()
{
	HeroTank::m_bulletVelocity = 200;                //�ӵ��ٶ�
	HeroTank::m_bulletPower = 1;                     //�ӵ�����
	HeroTank::m_boatSwitch = false;                  //�ɺӿ���
}
void HeroTank::blowUp()
{
	this->m_isCanMove = false;
	this->m_shootSwitch = false;
	this->tankMoveStop();


	SoundManager::playBlowUpSound();
	

	
	//this->getPhysicsBody()->removeFromWorld();
	auto animation = Animation::create();
	animation->addSpriteFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName("tankbomb_01.png"));
	animation->addSpriteFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName("tankbomb_02.png"));
	animation->addSpriteFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName("tankbomb_03.png"));
	animation->addSpriteFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName("tankbomb_04.png"));
	animation->addSpriteFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName("tankbomb_05.png"));

	animation->setDelayPerUnit(0.05);//��������֡����ʱ����
	animation->setLoops(1);//�����Ƿ�ѭ������,-1����ѭ��,����n����n��,0������
	animation->setRestoreOriginalFrame(false);//���ö�����������Ƿ�ص���һ֡
	auto _blowUp = Animate::create(animation);

	//������,̹�˱�ը��ص�������
	auto _func1 = CallFunc::create([this] {

		HeroTank::m_bulletVelocity = 200;                 //�ӵ��ٶ�
		HeroTank::m_bulletPower = 1;                      //�ӵ�����
		HeroTank::m_boatSwitch = false;                  //�ɺӿ���
		this->tankBear();                              //�����ҷ�̹��
	});

	//û����,̹�˱�ը����Ϸ����
	auto _func2 = CallFunc::create([this] {
		this->removeFromParent(); 
		GameScene::getMessageManager()->gameOver();
	});


	//û����
	if (GameScene::getHeroManager()->getTankLife() <= 0)
	{
		auto _act = Sequence::create(_blowUp, _func2, nullptr);
		this->runAction(_act);
	}

	//������
	else
	{
		auto _act = Sequence::create(_blowUp, _func1, nullptr);
		this->runAction(_act);
	}


	//this->removeFromParent();

}
