#include "cocos2d.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include "Item.h"
#include"GameScene.h"

USING_NS_CC;
using namespace cocostudio::timeline;
using namespace cocos2d::ui;

Item* Item::createItemWithType(int type)
{
	auto _item = new Item();
	if (_item&&_item->init(type))
	{
		_item->autorelease();
		return _item;
	}
	else
	{
		CC_SAFE_DELETE(_item);
		return nullptr;
	}
}
bool Item::init(int type)
{
	if (!Sprite::init())
	{
		return false;
	}
	this->m_type = type;
	this->itemInitWithType();

	this->setTag(GameScene::NodeTag::ITEM_TAG);
	float _ratio = 0.85;
	this->setScale(_ratio);
	//��������һ��body�ӵ�����������,���������óߴ���Զ�����,,�������ﲻ�ó�������ϵ��
	auto body = PhysicsBody::createBox(this->getContentSize(), PhysicsMaterial(10, 0, 0));
	body->setVelocity(Vec2(0, 0));
	body->setCategoryBitmask(GameScene::CategoryMaskBit::ITEM_CATEGORYMASKBIT);
	body->setContactTestBitmask(GameScene::ContactMaskBit::ITEM_CONTACTMASKBIT);
	body->setCollisionBitmask(0); //��������ײģ��
	this->setPhysicsBody(body);


	schedule(schedule_selector(Item::testPosition), 0.2);
	auto _blink = Blink::create(0.5, 1);
	auto _blinking = RepeatForever::create(_blink);
	this->runAction(_blinking);

	auto _func = CallFunc::create([this] {this->removeFromParent(); });
	auto _dt = DelayTime::create(15);
	auto _act = Sequence::create(_dt, _func, nullptr);
	this->runAction(_act);
	return true;
}
void Item::itemInitWithType()
{
    switch (m_type)
	{
	    case BOAT: 
	  {
		   this->initWithSpriteFrameName("boat.png");
		   this->setName("boat");
		   break;
	  }
	   case	GRENADE: 
	  {
		   this->initWithSpriteFrameName("grenade.png");
		   this->setName("grenade");
		   break;
	  }
	   case GUN: 
	  {
		   this->initWithSpriteFrameName("gun.png");
		   this->setName("gun");
		   break;
	  }
	   case HELMET:
	  {
		   this->initWithSpriteFrameName("helmet.png");
		   this->setName("helmet");
		   break;
	  }
	  case SPADE:
	  {
		 //  this->initWithSpriteFrameName("spade.png");
		 // this->setName("spade");
		  this->initWithSpriteFrameName("tankLife.png");
		  this->setName("tankLife");
		   break;
	  }
	   case STAR:
	  {
		   this->initWithSpriteFrameName("star.png");
		   this->setName("star");
		   break;
	  }
	  case STOPWATCH:
	  {
		  this->initWithSpriteFrameName("stopwatch.png");
		  this->setName("stopwatch");
		   break;
	  }
	  case TABKLIFE:
	  {
		  this->initWithSpriteFrameName("tankLife.png");
		  this->setName("tankLife");
		   break;
	  }

	}

	

}
void Item::onEnter()
{
	Sprite::onEnter();

}
void Item::onExit()
{
	Sprite::onExit();
}
void Item::testPosition(float dt)
{
	//log("item=%f,%f",this->getPositionX(), this->getPositionY());
	if (this->getPositionX() == 0|| this->getPositionY() == 0)
	{
		auto _posX = random(100, 300);
		auto _posY = random(100, 300);
		auto _pos = Vec2(_posX, _posY);	
		this->setPosition(_pos);
	}
}