#pragma once
#include "cocos2d.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include"Item.h"

USING_NS_CC;
using namespace cocostudio::timeline;
using namespace cocos2d::ui;

class ItemManager:public Layer
{
private:
	Layer* m_itemList;

public:
	bool init();
	CREATE_FUNC(ItemManager);
	Layer* getItemList() { return m_itemList; }
	void createItem();
	void onEnter();

};