#include "cocos2d.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include"GameScene.h"
#include"MapLayer.h"
#include"GameMenu.h"

USING_NS_CC;
using namespace cocostudio::timeline;
using namespace cocos2d::ui;


MapLayer* MapLayer::createMapWithRound(int round)
{
	auto _mapLayer = new MapLayer();
	if (_mapLayer&&_mapLayer->init(round))
	{
		_mapLayer->autorelease();
		return _mapLayer;
	}
	else
	{
		CC_SAFE_DELETE(_mapLayer);
		return nullptr;
	}

}
bool MapLayer::init(int round)
{
	if (!Layer::init())
	{
		return false;
	}
	sprintf(m_round, "map%d.tmx", round);
	m_map = TMXTiledMap::create(m_round);       //������ͼ
	this->addChild(m_map);
	//m_homeBrickList = Layer::create();
	m_homeSteelList = Layer::create();
	//this->addChild(m_homeBrickList,1);
	this->addChild(m_homeSteelList,2);
	m_layer1 = m_map->getLayer("layer1");         //�õ���ͼ�е�layer1

	this->addPhysicBody();                            //������Ƭ����ģ��
	//this->addHomeBrickWall();
	//this->addHomeSteelWall();
	this->addHome();
	GameScene::getMessageManager()->changeRoundPic(round);
	return true;
}
void MapLayer::onEnter()
{
	Layer::onEnter();
	
}
void MapLayer::addPhysicBody()
{
	auto  _layer1Size = m_layer1->getContentSize();
	auto  _tileSize = m_map->getTileSize();
	int _tileX = _layer1Size.width / _tileSize.width;                 //���������Ƭ�ж��ٿ�
	int _tileY = _layer1Size.height / _tileSize.height;               //����������Ƭ�ж��ٿ�

	//����ÿ����Ƭ,����Ӧ��Ƭ��������ģ��
	for (int _x = 0, _y = 0; _x < _tileX; _x++)
	{
		for (_x = _x, _y = 0; _y < _tileY; _y++)
		{
			if (auto _tile = m_layer1->getTileAt(Vec2(_x, _y)))
			{
				int _gid = m_layer1->getTileGIDAt(Vec2(_x, _y));//ͨ��������õ�gid�ǵ�ͼ���gid+1;
				auto _types = m_map->getPropertiesForGID(_gid).asValueMap();

				if (_types["type"].asString() == "brick")
				{
					_tile->setTag(GameScene::NodeTag::TILE_TAG);
					_tile->setName("brick");
					//��ÿ����Ƭ��һ��body����������ģ��
					auto body = PhysicsBody::createBox(_tile->getContentSize(), PhysicsMaterial(10, 0, 0));
					body->setCategoryBitmask(GameScene::CategoryMaskBit::TILE_CATEGORYMASKBIT);
					body->setContactTestBitmask(GameScene::ContactMaskBit::TILE_CONTACTMASKBIT);
					body->setCollisionBitmask(0); //��������ײģ�⣬��Ϊ����Ҫ��
					_tile->setPhysicsBody(body);
				}
				else if (_types["type"].asString() == "steel")
				{
					_tile->setTag(GameScene::NodeTag::TILE_TAG);
					_tile->setName("steel");
					//��ÿ����Ƭ��һ��body����������ģ��
					auto body = PhysicsBody::createBox(_tile->getContentSize(), PhysicsMaterial(10, 0, 0));
					body->setCategoryBitmask(GameScene::CategoryMaskBit::TILE_CATEGORYMASKBIT);
					body->setContactTestBitmask(GameScene::ContactMaskBit::TILE_CONTACTMASKBIT);
					body->setCollisionBitmask(0); //��������ײģ�⣬��Ϊ����Ҫ��
					_tile->setPhysicsBody(body);
				}


			}
		}
	}
}

void MapLayer::addHome()
{
	auto _objLayer1 = m_map->getObjectGroup("objLayer1");
	auto _homePlace = _objLayer1->getObject("homePlace");
	auto _homePos = Vec2(_homePlace["x"].asFloat(), _homePlace["y"].asFloat());
	//log("x=%f,y=%f", _homePos.x, _homePos.y);
	m_home = Sprite::create("home.png");
	m_home->setName("home");
	m_home->setPosition(_homePos);
	m_home->setTag(GameScene::NodeTag::HOME_TAG);
	this->addChild(m_home);

	//��home��һ��body����������ģ��
	auto body = PhysicsBody::createBox(m_home->getContentSize(), PhysicsMaterial(10, 0, 0));
	body->setCategoryBitmask(GameScene::CategoryMaskBit::TILE_CATEGORYMASKBIT);
	body->setContactTestBitmask(GameScene::ContactMaskBit::TILE_CONTACTMASKBIT);
	body->setCollisionBitmask(0); //��������ײģ�⣬��Ϊ����Ҫ��
	m_home->setPhysicsBody(body);


}
void MapLayer::destoryHome()
{
	auto _destoryHome = SpriteFrame::create("dieHome.png", Rect(0, 0, 32, 32));
	m_home->setSpriteFrame(_destoryHome);
	m_home->getPhysicsBody()->removeFromWorld();

	GameScene::getMessageManager()->gameOver();
}
/*
void MapLayer::addHomeBrickWall()
{
	AutoreleasePool _pool;
	auto _winSizeH = Director::getInstance()->getWinSize().height;
	Vec2 _wallPos[] = { Vec2(11,25),Vec2(11,24),Vec2(11,23),Vec2(12,23),Vec2(13,23),Vec2(14,23),Vec2(14,24),Vec2(14,25) };
	for (int i = 0; i < 8; i++)
	{
		
		//m_layer1->removeTileAt(_wallPos[i]);
		//m_layer1->setTileGID(5, _wallPos[i]);
		//auto _tile = m_layer1->getTileAt(_wallPos[i]);
		auto _tile = Sprite::createWithSpriteFrameName("steel.png");
		_tile->setAnchorPoint(Vec2(0, 0));
		_tile->setPosition(Vec2((_wallPos[i].x)*16, _winSizeH-(_wallPos[i].y+1)*16));
		_tile->setTag(GameScene::NodeTag::TILE_TAG);
		_tile->setName("steel");
		m_homeBrickList->addChild(_tile);

		//��ÿ����Ƭ��һ��body����������ģ��
		auto body = PhysicsBody::createBox(_tile->getContentSize(), PhysicsMaterial(10, 0, 0));
		body->setCategoryBitmask(GameScene::CategoryMaskBit::TILE_CATEGORYMASKBIT);
		body->setContactTestBitmask(GameScene::ContactMaskBit::TILE_CONTACTMASKBIT);
		body->setCollisionBitmask(0); //��������ײģ�⣬��Ϊ����Ҫ��
		_tile->setPhysicsBody(body);
	}

}

*/
void MapLayer::addHomeSteelWall()
{

	auto _winSizeH = Director::getInstance()->getWinSize().height;
	auto _wallPos = Vec2(11, 25);
	auto _tile = Sprite::create("steelHome.png");
	auto _size = _tile->getContentSize();
	_tile->setScale(64 /_size.width, 48 / _size.height);
	_tile->setAnchorPoint(Vec2(0, 0));
	_tile->setPosition(Vec2((_wallPos.x) * 16, _winSizeH - (_wallPos.y + 1) * 16));
	_tile->setTag(GameScene::NodeTag::TILE_TAG);
	_tile->setName("steel");
	this->addChild(_tile);


	//��ÿ����Ƭ��һ��body����������ģ��
	auto body = PhysicsBody::createBox(_tile->getContentSize(), PhysicsMaterial(1000, 0,1000));
	body->setCategoryBitmask(GameScene::CategoryMaskBit::STEEL_WALL_CATEGORYMASKBIT);
	body->setContactTestBitmask(GameScene::ContactMaskBit::STEEL_WALL_CONTACTMASKBIT);
	body->setCollisionBitmask(GameScene::CollisionMaskBit::STEEL_WALL_COLLISIONMASKBIT); //��������ײģ�⣬��Ϊ����Ҫ��
	_tile->setPhysicsBody(body);

	//log("steelWall.....");
}

void MapLayer::removeHomeSteelWall()
{
	//m_homeSteelList->removeChildByName("steel");
	//this->removeChildByTag(123);
}