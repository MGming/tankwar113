#include "cocos2d.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include"MapManager.h"
#include"GameScene.h"

USING_NS_CC;
using namespace cocostudio::timeline;
using namespace cocos2d::ui;

bool MapManager::init()
{
	if (!Layer::init())
	{
		return false;
	}
	this->selectMap(GameScene::m_round);
	return true;
}
void MapManager::selectMap(int round)
{
	if(m_mapLayer!=nullptr)
	m_mapLayer->removeFromParent();

	m_mapLayer = MapLayer::createMapWithRound(round);            //������ͼͼ�㲢���뵽��ͼ������
	this->addChild(m_mapLayer);
}