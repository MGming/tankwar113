#pragma once
#include "cocos2d.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include"MapLayer.h"

USING_NS_CC;
using namespace cocostudio::timeline;
using namespace cocos2d::ui;

class MapManager :public Layer
{
private:
	MapLayer* m_mapLayer;                 //��ͼͼ��

public:
	bool init();
	CREATE_FUNC(MapManager);
	MapLayer* getMapLayer() { return m_mapLayer; }           //�õ���ͼͼ��
	void selectMap(int round);                              //�ؿ�ѡ��

};
