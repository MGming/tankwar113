#include "cocos2d.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include "SimpleAudioEngine.h"
#include"MessageManager.h"
#include"SoundManager.h"
#include"GameScene.h"
#include"HeroManager.h"
#include"HeroTank.h"
#include"GameMenu.h"
#include"PauseScene.h"
#include"GradeScene.h"
#include"EnemyManager.h"




USING_NS_CC;
using namespace cocostudio::timeline;
using namespace cocos2d::ui;
using namespace CocosDenshion;

int MessageManager::m_totalScore = 0;

bool MessageManager::init()
{
	if (!Layer::init())
	{

		return false;
	}
	this->setSwallowsTouches(0);
	auto _messageLayer = CSLoader::createNode("MessageLayer.csb");
	this->addChild(_messageLayer);
	//this->m_totalScore = 0;


	//��ȡ��ť
	m_panel = (Layout*)_messageLayer->getChildByName("Panel");
	m_upButton = (Button*)Helper::seekWidgetByName(m_panel, "UpButton");
	m_downButton = (Button*)Helper::seekWidgetByName(m_panel, "DownButton");
	m_leftButton = (Button*)Helper::seekWidgetByName(m_panel, "LeftButton");
	m_rightButton = (Button*)Helper::seekWidgetByName(m_panel, "RightButton");
	m_shootButton = (Button*)Helper::seekWidgetByName(m_panel, "ShootButton");
	m_pauseButton = (Button*)Helper::seekWidgetByName(m_panel, "PauseButton");


	//��ȡtext
	m_scoreText = (Text*)Helper::seekWidgetByName(m_panel, "ScoreText");
	m_lifeText = (Text*)Helper::seekWidgetByName(m_panel, "LifeText");
	m_flagText = (Text*)Helper::seekWidgetByName(m_panel, "FlagText");
	m_roundText = (Text*)Helper::seekWidgetByName(m_panel, "RoundText");


	m_panel->setSwallowTouches(true);	

	//��ť���¼�
	m_upButton->addTouchEventListener(CC_CALLBACK_2(MessageManager::upMove, this));
	m_downButton->addTouchEventListener(CC_CALLBACK_2(MessageManager::downMove, this));
	m_leftButton->addTouchEventListener(CC_CALLBACK_2(MessageManager::leftMove, this));
	m_rightButton->addTouchEventListener(CC_CALLBACK_2(MessageManager::rightMove, this));
	m_shootButton->addTouchEventListener(CC_CALLBACK_2(MessageManager::tankShoot, this));
	m_pauseButton->addTouchEventListener(CC_CALLBACK_2(MessageManager::pauseGame, this));

	MessageManager::changeScorePic(0);

	return true;
}
void MessageManager::upMove(cocos2d::Object* pSender, Widget::TouchEventType type)
{
	switch (type)
	{
	case Widget::TouchEventType::BEGAN:
	{
		if (GameScene::getHeroManager()->getChildrenCount() == 0)
			return;

		GameScene::getHeroManager()->heroUpMove();
		//log("left");
	}
		break;
	case Widget::TouchEventType::MOVED:
		break;
	case Widget::TouchEventType::ENDED:
	{
		if (GameScene::getHeroManager()->getChildrenCount() == 0)
			return;
		//�ͷŷ����̹��ֹͣ�ƶ�	
		GameScene::getHeroManager()->getHeroTank()->tankMoveStop();

	}
		break;
	case Widget::TouchEventType::CANCELED:
		//�ͷŷ����̹��ֹͣ�ƶ�	
		GameScene::getHeroManager()->getHeroTank()->tankMoveStop();
		break;
	default:
		break;
	}


}
void MessageManager::downMove(cocos2d::Object* pSender, Widget::TouchEventType type)
{
	switch (type)
	{
	case Widget::TouchEventType::BEGAN:
	{
		if (GameScene::getHeroManager()->getChildrenCount() == 0)
			return;

		GameScene::getHeroManager()->heroDownMove();
		//log("left");
	}
		break;
	case Widget::TouchEventType::MOVED:
		break;
	case Widget::TouchEventType::ENDED:
	{
		if (GameScene::getHeroManager()->getChildrenCount() == 0)
			return;
		//�ͷŷ����̹��ֹͣ�ƶ�	
		GameScene::getHeroManager()->getHeroTank()->tankMoveStop();

	}

		break;
	case Widget::TouchEventType::CANCELED:
		//�ͷŷ����̹��ֹͣ�ƶ�	
		GameScene::getHeroManager()->getHeroTank()->tankMoveStop();
		break;
	default:
		break;
	}


}
void MessageManager::leftMove(cocos2d::Object* pSender, Widget::TouchEventType type)
{
	switch (type)
	{
	case Widget::TouchEventType::BEGAN:
	{
		if (GameScene::getHeroManager()->getChildrenCount() == 0)
			return;

		GameScene::getHeroManager()->heroLeftMove();
		//log("left");
	}
		break;
	case Widget::TouchEventType::MOVED:
		break;
	case Widget::TouchEventType::ENDED:
	{
		if (GameScene::getHeroManager()->getChildrenCount() == 0)
			return;
		//�ͷŷ����̹��ֹͣ�ƶ�	
		GameScene::getHeroManager()->getHeroTank()->tankMoveStop();

	}

		break;
	case Widget::TouchEventType::CANCELED:
		//�ͷŷ����̹��ֹͣ�ƶ�	
		GameScene::getHeroManager()->getHeroTank()->tankMoveStop();
		break;
	default:
		break;
	}


}
void MessageManager::rightMove(cocos2d::Object* pSender, Widget::TouchEventType type)
{
	switch (type)
	{
	case Widget::TouchEventType::BEGAN:
	{
		if (GameScene::getHeroManager()->getChildrenCount() == 0)
			return;

		GameScene::getHeroManager()->heroRightMove();
		//log("left");
	}
		break;
	case Widget::TouchEventType::MOVED:
		break;
	case Widget::TouchEventType::ENDED:
	{
		if (GameScene::getHeroManager()->getChildrenCount() == 0)
			return;
		//�ͷŷ����̹��ֹͣ�ƶ�	
		GameScene::getHeroManager()->getHeroTank()->tankMoveStop();

	}

		break;
	case Widget::TouchEventType::CANCELED:
		//�ͷŷ����̹��ֹͣ�ƶ�	
		GameScene::getHeroManager()->getHeroTank()->tankMoveStop();
		break;
	default:
		break;
	}


}
void MessageManager::tankShoot(cocos2d::Object* pSender, Widget::TouchEventType type)
{
	switch (type)
	{
	case Widget::TouchEventType::BEGAN:
	{
		if (GameScene::getHeroManager()->getChildrenCount() == 0)
			return;
		GameScene::getHeroManager()->getHeroTank()->shoot();	
		//log("shoot");
	}
		break;
	case Widget::TouchEventType::MOVED:
		break;
	case Widget::TouchEventType::ENDED:
				
		break;
	case Widget::TouchEventType::CANCELED:
		break;
	default:
		break;
	}
	
}
void MessageManager::removeTankPic(int num)
{
	char _ch[10];
	sprintf(_ch, "t_%d", num);
	m_panel->removeChildByName(_ch);
}
void MessageManager::changeLifePic(int life)
{
	char _ch[10];
	sprintf(_ch, "%d", life);
	m_lifeText->setText(_ch);

}
void MessageManager::changeScorePic(int tankScore)
{	
	m_totalScore+=tankScore;              //�ۼӷ���
	//log("%d,%d", tankScore, m_totalScore);
	char _ch[20] = {0};
	sprintf(_ch, "%d", m_totalScore);
	m_scoreText->setText(_ch);
}

void MessageManager::pauseGame(cocos2d::Object* pSender, Widget::TouchEventType type)
{
	switch (type)
	{
	case Widget::TouchEventType::BEGAN:
		break;
	case Widget::TouchEventType::MOVED:
		break;
	case Widget::TouchEventType::ENDED:
	{
		//����
		auto _winSize = Director::getInstance()->getWinSize();
		auto _tex = RenderTexture::create(_winSize.width, _winSize.height);
		_tex->begin();
		this->getParent()->visit();//�õݹ鷽�����������ڵ�ĸ��ڲ���������
		_tex->end();
		Director::getInstance()->pushScene(PauseScene::createScene(_tex));
	}
		break;
	case Widget::TouchEventType::CANCELED:
		break;
	default:
		break;
	}

}
void MessageManager::gameOver()
{
	SoundManager::stopAllSounds();
	if (GameScene::getHeroManager()->getHeroTank() != nullptr)            //����ҷ�̹�˻����������˳����ڵ�,���ܶ���
		GameScene::getHeroManager()->getHeroTank()->onExit();

	SoundManager::playGameOverSound();
	auto _winSize = Director::getInstance()->getWinSize();
	auto _gameOverLayer = CSLoader::createNode("GameOverLayer.csb");
	this->addChild(_gameOverLayer);
	_gameOverLayer->setAnchorPoint(Vec2(0.5, 0.5));
	_gameOverLayer->setPosition(Vec2(_winSize.width/2,_winSize.height/2));
	_gameOverLayer->setScale(0.4);

	auto _dt = DelayTime::create(2.5);
	auto _scale = ScaleTo::create(0.5, 1);
	_gameOverLayer->runAction(_scale);                       //ʧ�����������С���

	


	auto _func2 = CallFunc::create([] {

		int _count1 = 0, _count2 = 0, _count3 = 0, _count4 = 0;
		_count1 = EnemyManager::m_dieNormalCount;
		_count2 = EnemyManager::m_dieSpeedCount;
		_count3 = EnemyManager::m_dieShootCount;
		_count4 = EnemyManager::m_dieArmorCount;
		Director::getInstance()->replaceScene(TransitionFade::create(0.1f, GradeScene::createScene(_count1, _count2, _count3, _count4)));
	});

	auto _act = Sequence::create(_dt, _func2, nullptr);      //ʧ����������һ��ʱ���ת��Ʒֳ���
	this->runAction(_act);
	//Director::getInstance()->replaceScene(TransitionFade::create(2.0f, GameMenu::createScene()));
	

}
void MessageManager::changeRoundPic(int round)
{
	char _ch[10];
	sprintf(_ch, "%d", round);          
	m_roundText->setText(_ch);

}
void MessageManager::dataInit()
{
	MessageManager::m_totalScore = 0;
}
