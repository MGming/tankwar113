#pragma once
#include "cocos2d.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"


USING_NS_CC;
using namespace cocostudio::timeline;
using namespace cocos2d::ui;

class MessageManager :public cocos2d::Layer
{
private:
	Layout* m_panel;
	Button* m_upButton;
	Button* m_downButton;
	Button* m_leftButton;
	Button* m_rightButton;
	Button* m_shootButton;
	Button* m_pauseButton;

	Text* m_scoreText;
	Text* m_lifeText;
	Text* m_flagText;
	Text* m_roundText;
	static int m_totalScore;


public:
	bool init();
	void upMove(cocos2d::Object* pSender, Widget::TouchEventType type);                //̹������
	void downMove(cocos2d::Object* pSender, Widget::TouchEventType type);               //̹������
	void leftMove(cocos2d::Object* pSender, Widget::TouchEventType type);               //̹������
	void rightMove(cocos2d::Object* pSender, Widget::TouchEventType type);              //̹������
	void tankShoot(cocos2d::Object* pSender, Widget::TouchEventType type);               //̹�����
	void pauseGame(cocos2d::Object* pSender, Widget::TouchEventType type);               //��Ϸ��ͣ


	Layout* getPanel() { return m_panel; }
	void removeTankPic(int num);                                                   //�Ƴ�һ��̹�˱�־
	void changeLifePic(int life);                                                  //�ı���������ͼ��
	void changeScorePic(int tankScore);                                            //�ı����ͼ��
	void changeRoundPic(int round);                                                //�ı�ȼ�ͼ��
	void gameOver();                                                           //��Ϸ��������
	static void dataInit();                                                    //���ݳ�ʼ��

	CREATE_FUNC(MessageManager);

};