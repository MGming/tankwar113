#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include "SimpleAudioEngine.h"
#include"PauseScene.h"
#include"SoundManager.h"
#include"GameMenu.h"
#include "GameScene.h"

USING_NS_CC;
using namespace cocostudio::timeline;
using namespace cocos2d::ui;
using namespace CocosDenshion;

Scene* PauseScene::createScene(RenderTexture* tex)
{
	auto _scene = Scene::create();
	auto _layer = PauseScene::create();
	_scene->addChild(_layer);
	auto _bgTex = tex->getSprite()->getTexture();
	auto _bgSprite = Sprite::createWithTexture(_bgTex);
	_bgSprite->setFlipY(true);
	_bgSprite->setAnchorPoint(Vec2(0, 0));
	_layer->addChild(_bgSprite, 0);

	return _scene;
}
bool PauseScene::init()
{
	if (!Layer::init())
	{
		return false;
	}
	SoundManager::stopAllSounds();
	SoundManager::playGamePauseSound();

	//��ͣҳ��ͼ��
	m_pauseLayer = CSLoader::createNode("PauseScene.csb");
	this->addChild(m_pauseLayer,1);

	m_pausePanel = (Layout*)m_pauseLayer->getChildByName("Panel");

	//��ȡ��ť
	m_continueButton = (Button*)Helper::seekWidgetByName(m_pausePanel, "ContinueButton");
	m_giveUpButton = (Button*)Helper::seekWidgetByName(m_pausePanel, "GiveUpButton");

	//���¼�
	m_continueButton->addTouchEventListener(CC_CALLBACK_2(PauseScene::continueGame, this));
	m_giveUpButton->addTouchEventListener(CC_CALLBACK_2(PauseScene::giveUpGame, this));



	return true;

}
void PauseScene::continueGame(cocos2d::Object* pSender, Widget::TouchEventType type)
{
	switch (type)
	{
	case Widget::TouchEventType::BEGAN:
		break;
	case Widget::TouchEventType::MOVED:
		break;
	case Widget::TouchEventType::ENDED:
	{
		SoundManager::playBgSound();
		Director::getInstance()->popScene();
	}
	break;
	case Widget::TouchEventType::CANCELED:
		break;
	default:
		break;
	}


}
void PauseScene::giveUpGame(cocos2d::Object* pSender, Widget::TouchEventType type)
{
	switch (type)
	{
	case Widget::TouchEventType::BEGAN:
		break;
	case Widget::TouchEventType::MOVED:
		break;
	case Widget::TouchEventType::ENDED:
	{	
		Director::getInstance()->purgeCachedData();//Ϊ�˷�ֹ�ڴ�й©
		Director::getInstance()->popToRootScene();//Ϊ�˷�ֹ�ڴ�й©
		Director::getInstance()->replaceScene(TransitionFade::create(0.1f,GameMenu::createScene()));
	}
	break;
	case Widget::TouchEventType::CANCELED:
		break;
	default:
		break;
	}

}