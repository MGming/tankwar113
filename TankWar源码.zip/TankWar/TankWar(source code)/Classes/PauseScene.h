#pragma once
#include "cocos2d.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"

USING_NS_CC;
using namespace cocostudio::timeline;
using namespace cocos2d::ui;
class PauseScene :public Layer
{
private:
	Node * m_pauseLayer;
	Layout* m_pausePanel;
	Button* m_giveUpButton;
	Button* m_continueButton;


public:
	static Scene* createScene(RenderTexture* tex);
	bool init();
	CREATE_FUNC(PauseScene);
	void giveUpGame(cocos2d::Object* pSender, Widget::TouchEventType type);             //������Ϸ�ص��˵�
	void continueGame(cocos2d::Object* pSender, Widget::TouchEventType type);           //������Ϸ


};