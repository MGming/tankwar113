#include"SoundManager.h"
#include "SimpleAudioEngine.h"

USING_NS_CC;
using namespace CocosDenshion;

bool SoundManager::init()
{
	if (!Node::init())
	{
		return false;
	}	
	return true;
}

void SoundManager::playShootSound()
{
		//SimpleAudioEngine::getInstance()->playEffect("shoot.mp3", false);
		SimpleAudioEngine::getInstance()->playEffect("shoot.wav", false);
}
void SoundManager::playGameStartSound()
{
	//SimpleAudioEngine::getInstance()->playEffect("gameStart.mp3", false);
	SimpleAudioEngine::getInstance()->playEffect("gameStart.wav", false);
}
void SoundManager::playGetItemSound()
{
	//SimpleAudioEngine::getInstance()->playEffect("gainItem.mp3", false);
	SimpleAudioEngine::getInstance()->playEffect("gainItem.wav", false);
}
void SoundManager::playCreateItemSound()
{
	//SimpleAudioEngine::getInstance()->playEffect("createItem.mp3", false);
	SimpleAudioEngine::getInstance()->playEffect("createItem.wav", false);
}
void SoundManager::playBgSound()
{
	//SimpleAudioEngine::getInstance()->playBackgroundMusic("move.mp3", true);
	SimpleAudioEngine::getInstance()->playBackgroundMusic("move.wav", true);

}
void SoundManager::stopAllSounds()
{
	SimpleAudioEngine::getInstance()->stopAllEffects();
	SimpleAudioEngine::getInstance()->stopBackgroundMusic();
}
void SoundManager::playBlowUpSound()
{
	//SimpleAudioEngine::getInstance()->playEffect("bang.mp3", false);
	SimpleAudioEngine::getInstance()->playEffect("bang.wav", false);
}
void SoundManager::playGainLifeSound()
{
	//SimpleAudioEngine::getInstance()->playEffect("gainLife.mp3", false);
	SimpleAudioEngine::getInstance()->playEffect("gainLife.wav", false);
}
void SoundManager::playGainGrenadeSound()
{
	//SimpleAudioEngine::getInstance()->playEffect("gainGrenade.mp3", false);
	SimpleAudioEngine::getInstance()->playEffect("gainGrenade.wav", false);
}
void SoundManager::playGameOverSound()
{
	//SimpleAudioEngine::getInstance()->playEffect("gameOver.mp3", false);
	SimpleAudioEngine::getInstance()->playEffect("gameOver.wav", false);
}
void SoundManager::playGamePauseSound()
{
	//SimpleAudioEngine::getInstance()->playEffect("gamePause.mp3", false);
	SimpleAudioEngine::getInstance()->playEffect("gamePause.wav", false);
}
void SoundManager::playCountSound()
{
	//SimpleAudioEngine::getInstance()->playEffect("count.mp3", false);
	SimpleAudioEngine::getInstance()->playEffect("count.wav", false);
}